"""Multi-format executive report generation (Markdown, Plain Text, and CSV) in Python."""

from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from backend.analytics import compute_analytics_summary
from backend.expiry_engine import get_expired_items, get_upcoming_expirations
from backend.models import EnrichedPantryItem


BASE_DIR = Path(__file__).resolve().parent.parent
DEFAULT_REPORTS_DIR = BASE_DIR / "reports"


def _build_observations(summary: Dict[str, Any]) -> List[str]:
    """Generate human-readable analytical observations from summary metrics."""
    if summary["is_empty"]:
        return ["No food pantry items are currently recorded. Add or import items to begin tracking."]

    obs: List[str] = []
    total = summary["total_records"]
    expired = summary["expired_count"]
    today = summary["expires_today_count"]
    soon = summary["expiring_soon_count"]
    fresh = summary["fresh_count"]

    if expired > 0:
        pct = round((expired / total) * 100, 1)
        obs.append(
            f"URGENT: {expired} item(s) ({pct}% of inventory) have already expired and should be inspected/removed."
        )
    if today > 0:
        obs.append(
            f"IMMEDIATE ACTION: {today} item(s) expire today; prioritize meal planning or preservation."
        )
    if soon > 0:
        obs.append(
            f"UPCOMING WINDOW: {soon} item(s) expire within 1 to 7 days."
        )
    if fresh > 0:
        pct_fresh = round((fresh / total) * 100, 1)
        obs.append(
            f"STABLE STOCK: {fresh} item(s) ({pct_fresh}%) remain fresh with >7 days of shelf life."
        )

    obs.append(
        f"SHELF LIFE: Average remaining shelf life is {summary['avg_remaining_shelf_life_all']} days across all items "
        f"({summary['avg_remaining_shelf_life_active']} days across non-expired items)."
    )

    if summary["category_summary"]:
        top_cat = summary["category_summary"][0]
        obs.append(
            f"TOP CATEGORY: '{top_cat['category']}' accounts for {top_cat['count']} record(s) ({top_cat['percentage']}%)."
        )
    return obs


def generate_markdown_report(
    enriched_items: List[EnrichedPantryItem],
    output_dir: Optional[Path] = None,
) -> Path:
    """Generate a formatted Markdown (.md) summary report."""
    summary = compute_analytics_summary(enriched_items)
    upcoming = get_upcoming_expirations(enriched_items, within_days=7)
    expired = get_expired_items(enriched_items)
    observations = _build_observations(summary)

    target_dir = (Path(output_dir) if output_dir else DEFAULT_REPORTS_DIR) / "markdown"
    target_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_path = target_dir / f"pantry_report_{stamp}.md"

    lines: List[str] = [
        "# Food Expiry Tracker — Executive Inventory Report",
        "",
        f"- **Generated On:** {summary['generated_at']}",
        f"- **Total Records:** {summary['total_records']}",
        f"- **Total Inventory Quantity (sum across units):** {summary['total_quantity']}",
        f"- **Average Remaining Shelf Life (All Items):** {summary['avg_remaining_shelf_life_all']} days",
        f"- **Average Remaining Shelf Life (Active / Non-Expired):** {summary['avg_remaining_shelf_life_active']} days",
        "",
        "## Expiry Status Counts",
        "",
        "| Status | Count | Share (%) | Total Quantity |",
        "| --- | ---: | ---: | ---: |",
    ]
    for s in summary["status_summary"]:
        lines.append(f"| {s['status']} | {s['count']} | {s['percentage']}% | {s['quantity']} |")

    lines.extend(["", "## Category-Wise Summary", ""])
    if summary["category_summary"]:
        lines.extend([
            "| Category | Items | Share (%) | Total Quantity | Avg Days Remaining | At-Risk Items |",
            "| --- | ---: | ---: | ---: | ---: | ---: |",
        ])
        for c in summary["category_summary"]:
            lines.append(
                f"| {c['category']} | {c['count']} | {c['percentage']}% | {c['total_quantity']} | "
                f"{c['avg_days_remaining']} | {c['at_risk_count']} |"
            )
    else:
        lines.append("_No categories recorded._")

    lines.extend(["", "## Upcoming Expiry Records (Next 7 Days & Today)", ""])
    if upcoming:
        lines.extend([
            "| ID | Item Name | Category | Qty | Expiry Date | Days Remaining | Status | Location |",
            "| --- | --- | --- | ---: | --- | ---: | --- | --- |",
        ])
        for e in upcoming:
            i = e.item
            lines.append(
                f"| {i.item_id} | {i.name} | {i.category} | {i.quantity:g} {i.unit} | "
                f"{i.expiry_date} | {e.days_remaining} | {e.status} | {i.storage_location} |"
            )
    else:
        lines.append("_No items expiring within the next 7 days._")

    lines.extend(["", "## Expired Records", ""])
    if expired:
        lines.extend([
            "| ID | Item Name | Category | Qty | Expiry Date | Days Overdue | Location |",
            "| --- | --- | --- | ---: | --- | ---: | --- |",
        ])
        for e in expired:
            i = e.item
            lines.append(
                f"| {i.item_id} | {i.name} | {i.category} | {i.quantity:g} {i.unit} | "
                f"{i.expiry_date} | {abs(e.days_remaining)} | {i.storage_location} |"
            )
    else:
        lines.append("_No expired items recorded._")

    lines.extend(["", "## Key Observations", ""])
    for ob in observations:
        lines.append(f"- {ob}")

    lines.extend(["", "## Complete Pantry Inventory", ""])
    if enriched_items:
        lines.extend([
            "| ID | Item Name | Category | Qty | Purchase Date | Expiry Date | Days Remaining | Status | Location |",
            "| --- | --- | --- | ---: | --- | --- | ---: | --- | --- |",
        ])
        for e in sorted(enriched_items, key=lambda x: (x.days_remaining, x.item.name.lower())):
            i = e.item
            lines.append(
                f"| {i.item_id} | {i.name} | {i.category} | {i.quantity:g} {i.unit} | "
                f"{i.purchase_date} | {i.expiry_date} | {e.days_remaining} | {e.status} | {i.storage_location} |"
            )
    else:
        lines.append("_No pantry items recorded._")

    file_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return file_path


def generate_text_report(
    enriched_items: List[EnrichedPantryItem],
    output_dir: Optional[Path] = None,
) -> Path:
    """Generate a fixed-width Plain Text (.txt) summary report."""
    summary = compute_analytics_summary(enriched_items)
    upcoming = get_upcoming_expirations(enriched_items, within_days=7)
    expired = get_expired_items(enriched_items)
    observations = _build_observations(summary)

    target_dir = (Path(output_dir) if output_dir else DEFAULT_REPORTS_DIR) / "text"
    target_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_path = target_dir / f"pantry_report_{stamp}.txt"

    sep = "=" * 78
    sub_sep = "-" * 78
    lines: List[str] = [
        sep,
        "FOOD EXPIRY TRACKER - EXECUTIVE INVENTORY REPORT",
        sep,
        f"Report Generation Date : {summary['generated_at']}",
        f"Total Records          : {summary['total_records']}",
        f"Total Quantity Sum     : {summary['total_quantity']}",
        f"Avg Shelf Life (All)   : {summary['avg_remaining_shelf_life_all']} days",
        f"Avg Shelf Life (Active): {summary['avg_remaining_shelf_life_active']} days",
        "",
        "EXPIRY STATUS COUNTS",
        sub_sep,
    ]
    for s in summary["status_summary"]:
        lines.append(f"{s['status']:<18} | Count: {s['count']:>4} | Share: {s['percentage']:>5}% | Qty: {s['quantity']:>8}")

    lines.extend(["", "CATEGORY-WISE SUMMARY", sub_sep])
    if summary["category_summary"]:
        for c in summary["category_summary"]:
            lines.append(
                f"{c['category']:<16} | Items: {c['count']:>3} ({c['percentage']:>5}%) | "
                f"Qty: {c['total_quantity']:>7} | Avg Days: {c['avg_days_remaining']:>6}"
            )
    else:
        lines.append("No categories recorded.")

    lines.extend(["", "UPCOMING EXPIRY RECORDS (0 - 7 DAYS)", sub_sep])
    if upcoming:
        for e in upcoming:
            i = e.item
            lines.append(
                f"{i.item_id:<8} | {i.name[:24]:<24} | {i.expiry_date} | {e.days_remaining:>3}d | {e.status:<14} | {i.storage_location}"
            )
    else:
        lines.append("None.")

    lines.extend(["", "EXPIRED RECORDS", sub_sep])
    if expired:
        for e in expired:
            i = e.item
            lines.append(
                f"{i.item_id:<8} | {i.name[:24]:<24} | {i.expiry_date} | -{abs(e.days_remaining):>2}d | {i.storage_location}"
            )
    else:
        lines.append("None.")

    lines.extend(["", "COMPLETE PANTRY INVENTORY", sub_sep])
    if enriched_items:
        for e in sorted(enriched_items, key=lambda x: (x.days_remaining, x.item.name.lower())):
            i = e.item
            lines.append(
                f"{i.item_id:<8} | {i.name[:22]:<22} | {i.category:<12} | {i.expiry_date} | "
                f"{e.days_remaining:>4}d | {e.status:<13}"
            )
    else:
        lines.append("None.")

    lines.extend(["", "IMPORTANT OBSERVATIONS", sub_sep])
    for idx, ob in enumerate(observations, start=1):
        lines.append(f"{idx}. {ob}")
    lines.append(sep)

    file_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return file_path


def generate_csv_report(
    enriched_items: List[EnrichedPantryItem],
    output_dir: Optional[Path] = None,
) -> Path:
    """Generate a comprehensive CSV (.csv) report including summary metadata and item rows."""
    summary = compute_analytics_summary(enriched_items)
    target_dir = (Path(output_dir) if output_dir else DEFAULT_REPORTS_DIR) / "csv"
    target_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_path = target_dir / f"pantry_report_{stamp}.csv"

    with file_path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["SECTION", "METRIC_OR_ID", "NAME_OR_KEY", "CATEGORY_OR_VALUE", "QUANTITY", "UNIT", "PURCHASE_DATE", "EXPIRY_DATE", "DAYS_REMAINING", "STATUS", "STORAGE_LOCATION", "NOTES"])
        writer.writerow(["SUMMARY", "generated_at", summary["generated_at"], "", "", "", "", "", "", "", "", ""])
        writer.writerow(["SUMMARY", "total_records", summary["total_records"], "", "", "", "", "", "", "", "", ""])
        writer.writerow(["SUMMARY", "total_quantity", summary["total_quantity"], "", "", "", "", "", "", "", "", ""])
        writer.writerow(["SUMMARY", "avg_remaining_shelf_life_all_days", summary["avg_remaining_shelf_life_all"], "", "", "", "", "", "", "", "", ""])
        writer.writerow(["SUMMARY", "avg_remaining_shelf_life_active_days", summary["avg_remaining_shelf_life_active"], "", "", "", "", "", "", "", "", ""])
        for s in summary["status_summary"]:
            writer.writerow(["STATUS_COUNT", s["status"], s["count"], f"{s['percentage']}%", s["quantity"], "", "", "", "", "", "", ""])
        for c in summary["category_summary"]:
            writer.writerow(["CATEGORY_SUMMARY", c["category"], c["count"], f"{c['percentage']}%", c["total_quantity"], "", "", "", c["avg_days_remaining"], "", "", f"at_risk={c['at_risk_count']}"])
        for e in sorted(enriched_items, key=lambda x: (x.days_remaining, x.item.name.lower())):
            i = e.item
            writer.writerow([
                "ITEM",
                i.item_id,
                i.name,
                i.category,
                i.quantity,
                i.unit,
                i.purchase_date,
                i.expiry_date,
                e.days_remaining,
                e.status,
                i.storage_location,
                i.notes,
            ])

    return file_path


def list_generated_reports(output_dir: Optional[Path] = None) -> List[Dict[str, str]]:
    """List recently exported reports across markdown, text, and csv directories."""
    base = Path(output_dir) if output_dir else DEFAULT_REPORTS_DIR
    results: List[Dict[str, str]] = []
    for fmt_dir, fmt_label in [("markdown", "Markdown"), ("text", "Plain Text"), ("csv", "CSV")]:
        folder = base / fmt_dir
        if not folder.exists():
            continue
        for p in folder.iterdir():
            if p.is_file() and p.suffix in (".md", ".txt", ".csv"):
                stat = p.stat()
                results.append(
                    {
                        "filename": p.name,
                        "folder": fmt_dir,
                        "format": fmt_label,
                        "size_bytes": str(stat.st_size),
                        "modified": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                    }
                )
    results.sort(key=lambda r: r["modified"], reverse=True)
    return results
