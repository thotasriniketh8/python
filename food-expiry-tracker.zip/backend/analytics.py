"""Executive analytics using Pandas, NumPy, and Matplotlib (headless Agg backend)."""

from __future__ import annotations

import math
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from backend.models import (
    ALL_EXPIRY_STATUSES,
    EXPIRY_STATUS_EXPIRED,
    EXPIRY_STATUS_EXPIRES_TODAY,
    EXPIRY_STATUS_EXPIRING_SOON,
    EXPIRY_STATUS_FRESH,
    EnrichedPantryItem,
)


BASE_DIR = Path(__file__).resolve().parent.parent
DEFAULT_CHARTS_DIR = BASE_DIR / "reports" / "charts"

PALETTE = {
    "forest": "#1B4332",
    "fresh": "#2D6A4F",
    "sage": "#52B788",
    "amber": "#D97706",
    "orange": "#EA580C",
    "crimson": "#DC2626",
    "slate": "#475569",
    "canvas": "#FFFFFF",
    "grid": "#E2E6DF",
    "ink": "#16261E",
}

CATEGORY_COLORS = [
    "#1B4332", "#2D6A4F", "#40916C", "#52B788",
    "#74C69D", "#D97706", "#B45309", "#0F766E",
    "#334155", "#64748B", "#059669", "#84CC16",
]


def _items_to_dataframe(enriched_items: List[EnrichedPantryItem]) -> pd.DataFrame:
    """Convert enriched pantry items to a structured Pandas DataFrame."""
    if not enriched_items:
        return pd.DataFrame(
            columns=[
                "item_id", "name", "category", "quantity", "unit",
                "purchase_date", "expiry_date", "storage_location",
                "days_remaining", "status", "is_critical", "created_at",
            ]
        )
    rows = [e.to_dict() for e in enriched_items]
    df = pd.DataFrame(rows)
    df["quantity"] = pd.to_numeric(df["quantity"], errors="coerce").fillna(0.0)
    df["days_remaining"] = pd.to_numeric(df["days_remaining"], errors="coerce").fillna(0).astype(int)
    return df


def compute_analytics_summary(enriched_items: List[EnrichedPantryItem]) -> Dict[str, Any]:
    """
    Compute comprehensive executive summary metrics using Pandas & NumPy.

    Shelf-life definition:
    - `avg_remaining_shelf_life_all`: arithmetic mean of `days_remaining` across ALL items
      (expired items contribute negative days, reflecting overdue backlog).
    - `avg_remaining_shelf_life_active`: arithmetic mean of `days_remaining` across non-expired items
      (`days_remaining >= 0`) only, showing remaining window for usable stock.
    """
    df = _items_to_dataframe(enriched_items)
    total_records = int(len(df))

    if total_records == 0:
        return {
            "is_empty": True,
            "total_records": 0,
            "total_quantity": 0.0,
            "fresh_count": 0,
            "expiring_soon_count": 0,
            "expires_today_count": 0,
            "expired_count": 0,
            "expiring_combined_count": 0,
            "avg_remaining_shelf_life_all": 0.0,
            "avg_remaining_shelf_life_active": 0.0,
            "median_days_remaining": 0.0,
            "std_days_remaining": 0.0,
            "min_days_remaining": 0,
            "max_days_remaining": 0,
            "category_summary": [],
            "status_summary": [
                {"status": s, "count": 0, "percentage": 0.0, "quantity": 0.0}
                for s in ALL_EXPIRY_STATUSES
            ],
            "location_summary": [],
            "approaching_expiry": [],
            "horizon_buckets": [
                {"label": "Overdue (<0d)", "count": 0},
                {"label": "0-3 Days", "count": 0},
                {"label": "4-7 Days", "count": 0},
                {"label": "8-30 Days", "count": 0},
                {"label": "31-90 Days", "count": 0},
                {"label": "90+ Days", "count": 0},
            ],
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }

    days_arr = df["days_remaining"].to_numpy(dtype=float)
    qty_arr = df["quantity"].to_numpy(dtype=float)

    total_quantity = round(float(np.sum(qty_arr)), 2)
    avg_all = round(float(np.mean(days_arr)), 1)

    active_days = days_arr[days_arr >= 0]
    avg_active = round(float(np.mean(active_days)), 1) if active_days.size > 0 else 0.0

    median_days = round(float(np.median(days_arr)), 1)
    std_days = round(float(np.std(days_arr)), 1) if total_records > 1 else 0.0
    min_days = int(np.min(days_arr))
    max_days = int(np.max(days_arr))

    status_counts_series = df["status"].value_counts()
    fresh_count = int(status_counts_series.get(EXPIRY_STATUS_FRESH, 0))
    soon_count = int(status_counts_series.get(EXPIRY_STATUS_EXPIRING_SOON, 0))
    today_count = int(status_counts_series.get(EXPIRY_STATUS_EXPIRES_TODAY, 0))
    expired_count = int(status_counts_series.get(EXPIRY_STATUS_EXPIRED, 0))

    # Category-wise Pandas aggregation
    cat_grouped = (
        df.groupby("category", as_index=False)
        .agg(
            item_count=("item_id", "count"),
            total_quantity=("quantity", "sum"),
            avg_days_remaining=("days_remaining", "mean"),
            at_risk_count=("is_critical", "sum"),
        )
        .sort_values(by=["item_count", "category"], ascending=[False, True])
    )
    category_summary = []
    for _, row in cat_grouped.iterrows():
        cnt = int(row["item_count"])
        pct = round((cnt / total_records) * 100.0, 1)
        category_summary.append(
            {
                "category": str(row["category"]),
                "count": cnt,
                "percentage": pct,
                "total_quantity": round(float(row["total_quantity"]), 2),
                "avg_days_remaining": round(float(row["avg_days_remaining"]), 1),
                "at_risk_count": int(row["at_risk_count"]),
            }
        )

    # Status distribution summary
    status_summary = []
    for s in ALL_EXPIRY_STATUSES:
        sub = df[df["status"] == s]
        cnt = int(len(sub))
        qty_sum = round(float(sub["quantity"].sum()), 2) if cnt > 0 else 0.0
        pct = round((cnt / total_records) * 100.0, 1)
        status_summary.append(
            {
                "status": s,
                "count": cnt,
                "percentage": pct,
                "quantity": qty_sum,
            }
        )

    # Storage location distribution
    loc_grouped = (
        df.groupby("storage_location", as_index=False)
        .agg(item_count=("item_id", "count"), total_quantity=("quantity", "sum"))
        .sort_values(by=["item_count", "storage_location"], ascending=[False, True])
    )
    location_summary = [
        {
            "location": str(r["storage_location"]),
            "count": int(r["item_count"]),
            "total_quantity": round(float(r["total_quantity"]), 2),
        }
        for _, r in loc_grouped.iterrows()
    ]

    # Items approaching expiry (0 to 14 days)
    approaching_df = df[(df["days_remaining"] >= 0) & (df["days_remaining"] <= 14)].sort_values(
        by=["days_remaining", "name"]
    )
    approaching_expiry = approaching_df.to_dict(orient="records")

    # Shelf-life horizon buckets (NumPy histogram logic)
    horizon_buckets = [
        {"label": "Overdue (<0d)", "count": int(np.sum(days_arr < 0))},
        {"label": "0-3 Days", "count": int(np.sum((days_arr >= 0) & (days_arr <= 3)))},
        {"label": "4-7 Days", "count": int(np.sum((days_arr >= 4) & (days_arr <= 7)))},
        {"label": "8-30 Days", "count": int(np.sum((days_arr >= 8) & (days_arr <= 30)))},
        {"label": "31-90 Days", "count": int(np.sum((days_arr >= 31) & (days_arr <= 90)))},
        {"label": "90+ Days", "count": int(np.sum(days_arr > 90))},
    ]

    return {
        "is_empty": False,
        "total_records": total_records,
        "total_quantity": total_quantity,
        "fresh_count": fresh_count,
        "expiring_soon_count": soon_count,
        "expires_today_count": today_count,
        "expired_count": expired_count,
        "expiring_combined_count": soon_count + today_count,
        "avg_remaining_shelf_life_all": avg_all,
        "avg_remaining_shelf_life_active": avg_active,
        "median_days_remaining": median_days,
        "std_days_remaining": std_days,
        "min_days_remaining": min_days,
        "max_days_remaining": max_days,
        "category_summary": category_summary,
        "status_summary": status_summary,
        "location_summary": location_summary,
        "approaching_expiry": approaching_expiry,
        "horizon_buckets": horizon_buckets,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }


def _configure_axes(ax: plt.Axes, title: str) -> None:
    ax.set_facecolor(PALETTE["canvas"])
    ax.set_title(title, fontsize=12, fontweight="bold", color=PALETTE["ink"], pad=14, loc="left")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(PALETTE["grid"])
    ax.spines["bottom"].set_color(PALETTE["grid"])
    ax.tick_params(colors="#334155", labelsize=9)


def _save_empty_chart(out_path: Path, title: str, message: str) -> None:
    fig, ax = plt.subplots(figsize=(6.4, 4.0), dpi=150)
    fig.patch.set_facecolor(PALETTE["canvas"])
    ax.set_facecolor(PALETTE["canvas"])
    ax.axis("off")
    ax.set_title(title, fontsize=12, fontweight="bold", color=PALETTE["ink"], pad=12, loc="left")
    ax.text(
        0.5, 0.5, message,
        ha="center", va="center", fontsize=10.5, color="#64748B",
        bbox=dict(boxstyle="round,pad=0.8", facecolor="#F7F8F6", edgecolor="#E2E6DF"),
    )
    plt.tight_layout()
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def generate_all_charts(
    enriched_items: List[EnrichedPantryItem],
    charts_dir: Optional[Path] = None,
) -> Dict[str, str]:
    """
    Generate 4 Matplotlib analytical charts from Python data and save to disk.
    Returns mapping of chart key -> filename.
    """
    out_dir = Path(charts_dir) if charts_dir else DEFAULT_CHARTS_DIR
    out_dir.mkdir(parents=True, exist_ok=True)
    summary = compute_analytics_summary(enriched_items)

    filenames = {
        "category": "category_distribution.png",
        "status": "expiry_status_distribution.png",
        "upcoming": "upcoming_expiry_overview.png",
        "horizon": "inventory_summary_horizon.png",
    }

    # 1. Food Category Distribution (Doughnut Chart)
    cat_path = out_dir / filenames["category"]
    cat_data = summary["category_summary"]
    if not cat_data:
        _save_empty_chart(cat_path, "Food Category Distribution", "No pantry records available.")
    else:
        fig, ax = plt.subplots(figsize=(6.8, 4.7), dpi=150)
        fig.patch.set_facecolor(PALETTE["canvas"])
        labels = [c["category"] for c in cat_data]
        counts = [c["count"] for c in cat_data]
        colors = [CATEGORY_COLORS[i % len(CATEGORY_COLORS)] for i in range(len(labels))]

        wedges, texts, autotexts = ax.pie(
            counts,
            labels=None,
            autopct=lambda p: f"{p:.0f}%" if p >= 5 else "",
            pctdistance=0.77,
            startangle=140,
            colors=colors,
            wedgeprops=dict(width=0.42, edgecolor="white", linewidth=2),
        )
        for at in autotexts:
            at.set_color("white")
            at.set_fontsize(8.5)
            at.set_fontweight("bold")

        ax.text(0, 0.06, str(summary["total_records"]), ha="center", va="center", fontsize=18, fontweight="bold", color=PALETTE["ink"])
        ax.text(0, -0.14, "Items", ha="center", va="center", fontsize=9, color="#64748B")
        ax.legend(
            wedges,
            [f"{lbl} ({cnt})" for lbl, cnt in zip(labels, counts)],
            title="Categories",
            title_fontsize=9,
            fontsize=8,
            labelspacing=0.42,
            loc="center left",
            bbox_to_anchor=(1.02, 0.5),
            frameon=False,
        )
        ax.set_title("Food Category Distribution", fontsize=12, fontweight="bold", color=PALETTE["ink"], pad=12, loc="left")
        plt.tight_layout()
        fig.savefig(cat_path, dpi=150, bbox_inches="tight")
        plt.close(fig)

    # 2. Expiry Status Distribution (Bar Chart)
    status_path = out_dir / filenames["status"]
    if summary["is_empty"]:
        _save_empty_chart(status_path, "Expiry Status Distribution", "Add items to view expiry status counts.")
    else:
        fig, ax = plt.subplots(figsize=(6.4, 4.0), dpi=150)
        fig.patch.set_facecolor(PALETTE["canvas"])
        _configure_axes(ax, "Expiry Status Distribution")

        status_order = [
            (EXPIRY_STATUS_EXPIRED, PALETTE["crimson"]),
            (EXPIRY_STATUS_EXPIRES_TODAY, PALETTE["orange"]),
            (EXPIRY_STATUS_EXPIRING_SOON, PALETTE["amber"]),
            (EXPIRY_STATUS_FRESH, PALETTE["fresh"]),
        ]
        lookup = {s["status"]: s["count"] for s in summary["status_summary"]}
        x_labels = [s[0] for s in status_order]
        y_vals = [lookup.get(s[0], 0) for s in status_order]
        bar_colors = [s[1] for s in status_order]

        bars = ax.bar(x_labels, y_vals, color=bar_colors, width=0.52, zorder=3)
        ax.yaxis.grid(True, linestyle="--", alpha=0.6, color=PALETTE["grid"], zorder=0)
        ax.set_ylabel("Item Count", fontsize=9.5, color="#334155")
        max_y = max(y_vals) if y_vals else 1
        ax.set_ylim(0, max(max_y * 1.22, 2))

        for bar in bars:
            h = bar.get_height()
            ax.annotate(
                f"{int(h)}",
                xy=(bar.get_x() + bar.get_width() / 2, h),
                xytext=(0, 4),
                textcoords="offset points",
                ha="center", va="bottom",
                fontsize=9.5, fontweight="bold", color=PALETTE["ink"],
            )
        plt.tight_layout()
        fig.savefig(status_path, dpi=150, bbox_inches="tight")
        plt.close(fig)

    # 3. Upcoming Expiry Overview (Horizontal Bar Chart for items <= 10 days)
    upcoming_path = out_dir / filenames["upcoming"]
    upcoming_items = sorted(
        [e for e in enriched_items if e.days_remaining <= 10],
        key=lambda e: e.days_remaining,
    )[:12]
    if not upcoming_items:
        _save_empty_chart(
            upcoming_path,
            "Upcoming & Overdue Expiry Overview",
            "No items expiring within the next 10 days.",
        )
    else:
        fig, ax = plt.subplots(figsize=(6.4, 4.2), dpi=150)
        fig.patch.set_facecolor(PALETTE["canvas"])
        _configure_axes(ax, "Urgent & Upcoming Expiry Window (<= 10 Days)")

        names = [
            (e.item.name[:22] + "...") if len(e.item.name) > 25 else e.item.name
            for e in upcoming_items
        ]
        days = [e.days_remaining for e in upcoming_items]
        colors = [
            PALETTE["crimson"] if d < 0
            else PALETTE["orange"] if d == 0
            else PALETTE["amber"] if d <= 7
            else PALETTE["fresh"]
            for d in days
        ]

        y_pos = np.arange(len(names))
        bars = ax.barh(y_pos, days, color=colors, height=0.6, zorder=3)
        ax.set_yticks(y_pos)
        ax.set_yticklabels(names, fontsize=8.5)
        ax.invert_yaxis()
        ax.axvline(0, color="#334155", linewidth=1.0, zorder=4)
        ax.xaxis.grid(True, linestyle="--", alpha=0.6, color=PALETTE["grid"], zorder=0)
        ax.set_xlabel("Days Remaining (Negative = Overdue)", fontsize=9, color="#334155")

        min_d = min(days)
        max_d = max(days)
        pad_left = min(min_d - 2, -2) if min_d < 0 else -1
        pad_right = max(max_d + 2, 4)
        ax.set_xlim(pad_left, pad_right)

        for bar, d in zip(bars, days):
            offset = 4 if d >= 0 else -4
            ha = "left" if d >= 0 else "right"
            label = "Today" if d == 0 else f"{d}d"
            ax.annotate(
                label,
                xy=(d, bar.get_y() + bar.get_height() / 2),
                xytext=(offset, 0),
                textcoords="offset points",
                ha=ha, va="center",
                fontsize=8, fontweight="bold", color=PALETTE["ink"],
            )
        plt.tight_layout()
        fig.savefig(upcoming_path, dpi=150, bbox_inches="tight")
        plt.close(fig)

    # 4. Inventory Shelf-Life Horizon Summary
    horizon_path = out_dir / filenames["horizon"]
    if summary["is_empty"]:
        _save_empty_chart(horizon_path, "Inventory Shelf-Life Horizon", "No pantry records available.")
    else:
        fig, ax = plt.subplots(figsize=(6.4, 4.0), dpi=150)
        fig.patch.set_facecolor(PALETTE["canvas"])
        _configure_axes(ax, "Inventory Shelf-Life Horizon")

        buckets = summary["horizon_buckets"]
        b_labels = [b["label"] for b in buckets]
        b_counts = [b["count"] for b in buckets]
        b_colors = [
            PALETTE["crimson"],
            PALETTE["orange"],
            PALETTE["amber"],
            PALETTE["sage"],
            PALETTE["fresh"],
            PALETTE["forest"],
        ]

        bars = ax.bar(b_labels, b_counts, color=b_colors, width=0.56, zorder=3)
        ax.yaxis.grid(True, linestyle="--", alpha=0.6, color=PALETTE["grid"], zorder=0)
        ax.set_ylabel("Item Count", fontsize=9.5, color="#334155")
        ax.tick_params(axis="x", labelsize=8)
        max_b = max(b_counts) if b_counts else 1
        ax.set_ylim(0, max(max_b * 1.22, 2))

        for bar in bars:
            h = bar.get_height()
            ax.annotate(
                f"{int(h)}",
                xy=(bar.get_x() + bar.get_width() / 2, h),
                xytext=(0, 4),
                textcoords="offset points",
                ha="center", va="bottom",
                fontsize=9, fontweight="bold", color=PALETTE["ink"],
            )
        plt.tight_layout()
        fig.savefig(horizon_path, dpi=150, bbox_inches="tight")
        plt.close(fig)

    return filenames
