"""High-level inventory management service shared by the Flask web app and Python CLI."""

from __future__ import annotations

import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from backend.expiry_engine import (
    DEFAULT_THRESHOLDS,
    ExpiryThresholds,
    count_by_status,
    enrich_all,
    enrich_item,
    get_expired_items,
    get_expires_today_items,
    get_upcoming_expirations,
    identify_critical_situations,
)
from backend.models import EnrichedPantryItem, PantryItem
from backend.storage import PantryStorage, build_sample_records
from backend.validation import validate_item_payload


class InventoryService:
    """Coordinates CRUD operations, live expiry calculations, and persistent storage."""

    def __init__(
        self,
        data_dir: Optional[Path] = None,
        thresholds: ExpiryThresholds = DEFAULT_THRESHOLDS,
    ):
        self.storage = PantryStorage(data_dir=data_dir)
        self.thresholds = thresholds

    def _generate_item_id(self, existing: List[PantryItem]) -> str:
        existing_ids = {item.item_id for item in existing}
        seq = len(existing) + 1001
        while f"FD-{seq}" in existing_ids:
            seq += 1
        candidate = f"FD-{seq}"
        if candidate in existing_ids:
            candidate = f"FD-{uuid.uuid4().hex[:6].upper()}"
        return candidate

    def load_all(self) -> Tuple[List[EnrichedPantryItem], List[str]]:
        """Load items from storage and dynamically calculate live expiry statuses."""
        result = self.storage.load_items()
        enriched = enrich_all(result.items, thresholds=self.thresholds)
        return enriched, result.warnings

    def get_item(self, item_id: str) -> Optional[EnrichedPantryItem]:
        """Retrieve a single enriched item by ID."""
        result = self.storage.load_items()
        target = next((i for i in result.items if i.item_id == item_id), None)
        if target is None:
            return None
        return enrich_item(target, thresholds=self.thresholds)

    def add_item(
        self, payload: Dict[str, Any], check_duplicates: bool = True
    ) -> Tuple[Optional[EnrichedPantryItem], Dict[str, str]]:
        """Validate and persist a new pantry item."""
        load_res = self.storage.load_items()
        cleaned, errors = validate_item_payload(
            payload,
            existing_items=load_res.items,
            check_duplicates=check_duplicates,
        )
        if errors:
            return None, errors

        new_item = PantryItem(
            item_id=self._generate_item_id(load_res.items),
            name=cleaned["name"],
            category=cleaned["category"],
            quantity=cleaned["quantity"],
            unit=cleaned["unit"],
            purchase_date=cleaned["purchase_date"],
            expiry_date=cleaned["expiry_date"],
            storage_location=cleaned["storage_location"],
            notes=cleaned["notes"],
            created_at=datetime.now().isoformat(timespec="seconds"),
        )
        items = load_res.items + [new_item]
        self.storage.save_items(items)
        return enrich_item(new_item, thresholds=self.thresholds), {}

    def update_item(
        self, item_id: str, payload: Dict[str, Any]
    ) -> Tuple[Optional[EnrichedPantryItem], Dict[str, str]]:
        """Validate and update an existing pantry item."""
        load_res = self.storage.load_items()
        idx = next((i for i, item in enumerate(load_res.items) if item.item_id == item_id), None)
        if idx is None:
            return None, {"not_found": f"Item '{item_id}' was not found."}

        cleaned, errors = validate_item_payload(
            payload,
            existing_items=load_res.items,
            ignore_item_id=item_id,
            check_duplicates=True,
        )
        if errors:
            return None, errors

        existing_item = load_res.items[idx]
        updated = PantryItem(
            item_id=existing_item.item_id,
            name=cleaned["name"],
            category=cleaned["category"],
            quantity=cleaned["quantity"],
            unit=cleaned["unit"],
            purchase_date=cleaned["purchase_date"],
            expiry_date=cleaned["expiry_date"],
            storage_location=cleaned["storage_location"],
            notes=cleaned["notes"],
            created_at=existing_item.created_at,
        )
        items = list(load_res.items)
        items[idx] = updated
        self.storage.save_items(items)
        return enrich_item(updated, thresholds=self.thresholds), {}

    def delete_item(self, item_id: str) -> Tuple[bool, Optional[PantryItem]]:
        """Delete an item by ID and update JSON/CSV storage."""
        load_res = self.storage.load_items()
        target = next((item for item in load_res.items if item.item_id == item_id), None)
        if target is None:
            return False, None
        remaining = [item for item in load_res.items if item.item_id != item_id]
        self.storage.save_items(remaining)
        return True, target

    def restore_demo_dataset(self, overwrite: bool = False) -> Tuple[int, int]:
        """
        Load realistic sample dataset records.
        If overwrite=False, merges non-duplicate demo records without wiping user items.
        Returns (added_count, skipped_count).
        """
        sample_records = build_sample_records()
        if overwrite:
            self.storage.save_items(sample_records)
            return len(sample_records), 0

        load_res = self.storage.load_items()
        items = list(load_res.items)
        existing_sigs = {
            (
                i.name.strip().lower(),
                i.category.strip().lower(),
                i.expiry_date,
                i.storage_location.strip().lower(),
            )
            for i in items
        }
        added = 0
        skipped = 0
        for rec in sample_records:
            sig = (
                rec.name.strip().lower(),
                rec.category.strip().lower(),
                rec.expiry_date,
                rec.storage_location.strip().lower(),
            )
            if sig in existing_sigs:
                skipped += 1
                continue
            new_id = self._generate_item_id(items)
            rec.item_id = new_id
            items.append(rec)
            existing_sigs.add(sig)
            added += 1

        if added > 0:
            self.storage.save_items(items)
        return added, skipped

    def get_dashboard_summary(self) -> Dict[str, Any]:
        """Compute dynamic dashboard metrics directly from Python data."""
        enriched, warnings = self.load_all()
        status_counts = count_by_status(enriched)
        total_quantity = round(sum(e.item.quantity for e in enriched), 2)

        category_counts: Dict[str, int] = {}
        for e in enriched:
            category_counts[e.item.category] = category_counts.get(e.item.category, 0) + 1
        sorted_categories = sorted(category_counts.items(), key=lambda kv: (-kv[1], kv[0]))

        recent_additions = sorted(
            enriched,
            key=lambda e: (e.item.created_at, e.item.item_id),
            reverse=True,
        )[:6]

        upcoming_list = get_upcoming_expirations(enriched, within_days=self.thresholds.expiring_soon_days)
        expired_list = get_expired_items(enriched)
        expires_today_list = get_expires_today_items(enriched)
        critical_warnings = identify_critical_situations(enriched, thresholds=self.thresholds)

        return {
            "total_items": len(enriched),
            "fresh_count": status_counts["Fresh"],
            "expiring_soon_count": status_counts["Expiring Soon"],
            "expires_today_count": status_counts["Expires Today"],
            "expired_count": status_counts["Expired"],
            "total_quantity": total_quantity,
            "status_counts": status_counts,
            "category_distribution": sorted_categories,
            "recent_additions": recent_additions,
            "upcoming_list": upcoming_list[:8],
            "expired_list": expired_list,
            "expires_today_list": expires_today_list,
            "critical_warnings": critical_warnings,
            "storage_warnings": warnings,
        }
