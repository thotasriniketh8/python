"""Bulk CSV dataset import and validation engine."""

from __future__ import annotations

import csv
import io
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from backend.inventory import InventoryService
from backend.models import PantryItem
from backend.validation import validate_item_payload


REQUIRED_IMPORT_COLUMNS = [
    "name",
    "category",
    "quantity",
    "unit",
    "purchase_date",
    "expiry_date",
    "storage_location",
]


@dataclass
class ImportSummary:
    """Detailed outcome of a bulk CSV dataset import operation."""

    total_rows: int = 0
    imported_count: int = 0
    failed_count: int = 0
    duplicate_count: int = 0
    header_errors: List[str] = field(default_factory=list)
    row_errors: List[Dict[str, Any]] = field(default_factory=list)
    imported_items: List[Dict[str, Any]] = field(default_factory=list)

    @property
    def success(self) -> bool:
        return len(self.header_errors) == 0


def import_csv_text(
    csv_text: str,
    inventory_service: InventoryService,
) -> ImportSummary:
    """
    Validate and import pantry records from raw CSV content.
    Preserves valid rows even when other rows fail validation.
    """
    summary = ImportSummary()
    if not csv_text or not csv_text.strip():
        summary.header_errors.append("The uploaded CSV file is empty.")
        return summary

    # Strip UTF-8 BOM if present
    cleaned_text = csv_text.lstrip("\ufeff")
    stream = io.StringIO(cleaned_text)

    try:
        reader = csv.DictReader(stream)
    except csv.Error as exc:
        summary.header_errors.append(f"Unable to parse CSV structure: {exc}")
        return summary

    if not reader.fieldnames:
        summary.header_errors.append("CSV header row is missing.")
        return summary

    normalized_headers = [h.strip().lower() for h in reader.fieldnames if h is not None]
    missing_cols = [col for col in REQUIRED_IMPORT_COLUMNS if col not in normalized_headers]
    if missing_cols:
        summary.header_errors.append(
            f"Missing required CSV column(s): {', '.join(missing_cols)}. "
            f"Required columns: {', '.join(REQUIRED_IMPORT_COLUMNS)}."
        )
        return summary

    load_res = inventory_service.storage.load_items()
    working_items: List[PantryItem] = list(load_res.items)
    newly_added: List[PantryItem] = []

    try:
        for row_num, raw_row in enumerate(reader, start=2):
            summary.total_rows += 1
            # Normalize keys to lowercase
            normalized_row: Dict[str, Any] = {}
            for k, v in raw_row.items():
                if k is None:
                    continue
                normalized_row[k.strip().lower()] = v.strip() if isinstance(v, str) else v

            # Skip completely blank rows
            if all(str(val or "").strip() == "" for val in normalized_row.values()):
                summary.failed_count += 1
                summary.row_errors.append(
                    {"row": row_num, "name": "(blank row)", "errors": ["Row contains no data."]}
                )
                continue

            cleaned, field_errors = validate_item_payload(
                normalized_row,
                existing_items=working_items,
                check_duplicates=True,
            )

            if field_errors:
                summary.failed_count += 1
                if "duplicate" in field_errors:
                    summary.duplicate_count += 1
                summary.row_errors.append(
                    {
                        "row": row_num,
                        "name": normalized_row.get("name") or "(unnamed)",
                        "errors": list(field_errors.values()),
                    }
                )
                continue

            new_id = inventory_service._generate_item_id(working_items)
            new_item = PantryItem(
                item_id=new_id,
                name=cleaned["name"],
                category=cleaned["category"],
                quantity=cleaned["quantity"],
                unit=cleaned["unit"],
                purchase_date=cleaned["purchase_date"],
                expiry_date=cleaned["expiry_date"],
                storage_location=cleaned["storage_location"],
                notes=cleaned["notes"],
                created_at=datetime.now().isoformat(timespec="seconds"),
            )
            working_items.append(new_item)
            newly_added.append(new_item)
            summary.imported_count += 1
            summary.imported_items.append(new_item.to_dict())
    except csv.Error as exc:
        summary.header_errors.append(f"CSV parsing interrupted: {exc}")

    if newly_added:
        inventory_service.storage.save_items(working_items)

    return summary


def import_csv_file(
    file_path: Path,
    inventory_service: InventoryService,
) -> ImportSummary:
    """Import records from a local CSV file path with safe decoding."""
    summary = ImportSummary()
    path = Path(file_path)
    if not path.exists():
        summary.header_errors.append(f"File not found: '{path}'.")
        return summary
    if path.suffix.lower() != ".csv":
        summary.header_errors.append("Invalid file type. Only .csv files are accepted.")
        return summary

    try:
        content = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        try:
            content = path.read_text(encoding="latin-1")
        except OSError as exc:
            summary.header_errors.append(f"Unable to read file: {exc}")
            return summary
    except PermissionError:
        summary.header_errors.append(f"Permission denied reading '{path.name}'.")
        return summary
    except OSError as exc:
        summary.header_errors.append(f"Error reading file: {exc}")
        return summary

    return import_csv_text(content, inventory_service)
