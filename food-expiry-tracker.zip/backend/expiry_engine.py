"""Core Python datetime expiry calculation and classification engine."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from typing import Dict, List, Optional

from backend.models import (
    ALL_EXPIRY_STATUSES,
    EXPIRY_STATUS_EXPIRED,
    EXPIRY_STATUS_EXPIRES_TODAY,
    EXPIRY_STATUS_EXPIRING_SOON,
    EXPIRY_STATUS_FRESH,
    EnrichedPantryItem,
    PantryItem,
)


@dataclass(frozen=True)
class ExpiryThresholds:
    """Configurable thresholds (in days) for expiry status classification."""

    expiring_soon_days: int = 7
    critical_soon_days: int = 2
    overdue_critical_days: int = -3
    max_shelf_life_warning_days: int = 1825  # 5 years


DEFAULT_THRESHOLDS = ExpiryThresholds()


def parse_date_safe(date_str: str) -> Optional[date]:
    """Safely parse YYYY-MM-DD into a datetime.date object."""
    try:
        return datetime.strptime(str(date_str).strip(), "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return None


def calculate_days_remaining(expiry_date_str: str, reference_date: Optional[date] = None) -> int:
    """
    Calculate the integer number of days remaining until expiry.
    Positive => days left; 0 => expires today; negative => days overdue.
    """
    ref = reference_date or date.today()
    exp_date = parse_date_safe(expiry_date_str)
    if exp_date is None:
        raise ValueError(f"Invalid expiry date: '{expiry_date_str}'")
    return (exp_date - ref).days


def classify_expiry_status(
    days_remaining: int, thresholds: ExpiryThresholds = DEFAULT_THRESHOLDS
) -> str:
    """
    Classify an item into one of four mandatory expiry states:
    - Fresh: more than `expiring_soon_days` (default 7) remaining
    - Expiring Soon: 1 to `expiring_soon_days` remaining
    - Expires Today: 0 days remaining
    - Expired: negative days remaining
    """
    if days_remaining < 0:
        return EXPIRY_STATUS_EXPIRED
    if days_remaining == 0:
        return EXPIRY_STATUS_EXPIRES_TODAY
    if 1 <= days_remaining <= thresholds.expiring_soon_days:
        return EXPIRY_STATUS_EXPIRING_SOON
    return EXPIRY_STATUS_FRESH


def detect_anomaly(
    item: PantryItem,
    days_remaining: int,
    thresholds: ExpiryThresholds = DEFAULT_THRESHOLDS,
) -> Optional[str]:
    """Detect anomalous or boundary conditions on a pantry record."""
    p_date = parse_date_safe(item.purchase_date)
    e_date = parse_date_safe(item.expiry_date)
    if p_date is None or e_date is None:
        return "Invalid date format detected in record."
    if e_date < p_date:
        return "Expiry date precedes purchase date."
    if days_remaining <= thresholds.overdue_critical_days:
        return f"Severely overdue by {abs(days_remaining)} days."
    if (e_date - p_date).days > thresholds.max_shelf_life_warning_days:
        return "Unusually long shelf life (> 5 years); verify expiry date."
    if item.quantity <= 0:
        return "Non-positive quantity detected."
    if item.quantity >= 1000:
        return "Unusually large quantity; verify unit of measurement."
    return None


def enrich_item(
    item: PantryItem,
    reference_date: Optional[date] = None,
    thresholds: ExpiryThresholds = DEFAULT_THRESHOLDS,
) -> EnrichedPantryItem:
    """Enrich a PantryItem with dynamically computed expiry status and warnings."""
    days_remaining = calculate_days_remaining(item.expiry_date, reference_date=reference_date)
    status = classify_expiry_status(days_remaining, thresholds=thresholds)
    is_critical = status in (EXPIRY_STATUS_EXPIRED, EXPIRY_STATUS_EXPIRES_TODAY) or (
        0 < days_remaining <= thresholds.critical_soon_days
    )
    anomaly = detect_anomaly(item, days_remaining, thresholds=thresholds)
    return EnrichedPantryItem(
        item=item,
        days_remaining=days_remaining,
        status=status,
        is_critical=is_critical,
        anomaly_warning=anomaly,
    )


def enrich_all(
    items: List[PantryItem],
    reference_date: Optional[date] = None,
    thresholds: ExpiryThresholds = DEFAULT_THRESHOLDS,
) -> List[EnrichedPantryItem]:
    """Recalculate statuses for all pantry items dynamically."""
    ref = reference_date or date.today()
    enriched: List[EnrichedPantryItem] = []
    for item in items:
        try:
            enriched.append(enrich_item(item, reference_date=ref, thresholds=thresholds))
        except ValueError:
            # Keep corrupted-date item visible as anomalous instead of crashing
            enriched.append(
                EnrichedPantryItem(
                    item=item,
                    days_remaining=-9999,
                    status=EXPIRY_STATUS_EXPIRED,
                    is_critical=True,
                    anomaly_warning="Corrupted expiry date cannot be parsed.",
                )
            )
    return enriched


def get_upcoming_expirations(
    enriched_items: List[EnrichedPantryItem], within_days: int = 7
) -> List[EnrichedPantryItem]:
    """Return items expiring today or within `within_days`, sorted most urgent first."""
    upcoming = [
        e for e in enriched_items if 0 <= e.days_remaining <= within_days
    ]
    return sorted(upcoming, key=lambda e: (e.days_remaining, e.item.name.lower()))


def get_expiring_soon_only(
    enriched_items: List[EnrichedPantryItem], within_days: int = 7
) -> List[EnrichedPantryItem]:
    """Return items with 1 to `within_days` remaining (Expiring Soon)."""
    soon = [e for e in enriched_items if 1 <= e.days_remaining <= within_days]
    return sorted(soon, key=lambda e: (e.days_remaining, e.item.name.lower()))


def get_expires_today_items(enriched_items: List[EnrichedPantryItem]) -> List[EnrichedPantryItem]:
    """Return items whose expiry date is today."""
    today_items = [e for e in enriched_items if e.status == EXPIRY_STATUS_EXPIRES_TODAY]
    return sorted(today_items, key=lambda e: e.item.name.lower())


def get_expired_items(enriched_items: List[EnrichedPantryItem]) -> List[EnrichedPantryItem]:
    """Return items that have already expired, sorted most overdue first."""
    expired = [e for e in enriched_items if e.status == EXPIRY_STATUS_EXPIRED]
    return sorted(expired, key=lambda e: (e.days_remaining, e.item.name.lower()))


def count_by_status(enriched_items: List[EnrichedPantryItem]) -> Dict[str, int]:
    """Count pantry items in each expiry status."""
    counts: Dict[str, int] = {status: 0 for status in ALL_EXPIRY_STATUSES}
    for e in enriched_items:
        counts[e.status] = counts.get(e.status, 0) + 1
    return counts


def identify_critical_situations(
    enriched_items: List[EnrichedPantryItem],
    thresholds: ExpiryThresholds = DEFAULT_THRESHOLDS,
) -> List[Dict[str, str]]:
    """
    Generate automated dynamic threshold warnings for critical expiry conditions,
    overdue items, and anomalous entries.
    """
    warnings: List[Dict[str, str]] = []
    counts = count_by_status(enriched_items)

    if counts[EXPIRY_STATUS_EXPIRED] > 0:
        warnings.append(
            {
                "severity": "critical",
                "title": f"{counts[EXPIRY_STATUS_EXPIRED]} Expired Item(s) in Inventory",
                "detail": "Remove or dispose of overdue food items immediately to prevent spoilage contamination.",
            }
        )
    if counts[EXPIRY_STATUS_EXPIRES_TODAY] > 0:
        warnings.append(
            {
                "severity": "high",
                "title": f"{counts[EXPIRY_STATUS_EXPIRES_TODAY]} Item(s) Expire Today",
                "detail": "Prioritize consuming or preserving these items before end of day.",
            }
        )

    urgent_soon = [
        e for e in enriched_items if 1 <= e.days_remaining <= thresholds.critical_soon_days
    ]
    if urgent_soon:
        names = ", ".join(e.item.name for e in urgent_soon[:4])
        extra = f" (+{len(urgent_soon) - 4} more)" if len(urgent_soon) > 4 else ""
        warnings.append(
            {
                "severity": "warning",
                "title": f"{len(urgent_soon)} Item(s) Within {thresholds.critical_soon_days}-Day Window",
                "detail": f"Approaching immediate expiry: {names}{extra}.",
            }
        )

    anomalies = [e for e in enriched_items if e.anomaly_warning]
    if anomalies:
        warnings.append(
            {
                "severity": "anomaly",
                "title": f"{len(anomalies)} Record(s) with Anomaly Flags",
                "detail": "Review flagged entries for severe overdue status or unusual quantity/shelf-life values.",
            }
        )

    return warnings
