"""Centralized defensive input validation for both CLI and Web interfaces."""

from __future__ import annotations

import re
from datetime import date, datetime
from typing import Any, Dict, List, Optional, Tuple

from backend.models import FOOD_CATEGORIES, PantryItem


NAME_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9\s\-\.\,\&\(\)\/\'\%]{0,79}$")
UNIT_PATTERN = re.compile(r"^[A-Za-z][A-Za-z0-9\s\.\-\/]{0,19}$")
DATE_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}$")
LOCATION_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9\s\-\.\,\(\)\/]{0,49}$")


class ValidationError(Exception):
    """Raised when validation fails with field-level error details."""

    def __init__(self, errors: Dict[str, str]):
        self.errors = errors
        message = "; ".join(f"{field}: {msg}" for field, msg in errors.items())
        super().__init__(message)


def parse_iso_date(value: Any) -> Tuple[Optional[date], Optional[str]]:
    """Parse a YYYY-MM-DD string into a datetime.date with friendly error message."""
    if value is None:
        return None, "Date is required."
    text = str(value).strip()
    if not text:
        return None, "Date cannot be empty."
    if not DATE_PATTERN.match(text):
        return None, "Date must follow YYYY-MM-DD format (e.g., 2026-12-31)."
    try:
        parsed = datetime.strptime(text, "%Y-%m-%d").date()
        return parsed, None
    except ValueError:
        return None, f"'{text}' is not a valid calendar date."


def validate_name(value: Any) -> Tuple[str, Optional[str]]:
    """Validate food item name."""
    if value is None:
        return "", "Food item name is required."
    text = re.sub(r"\s+", " ", str(value).strip())
    if not text:
        return "", "Food item name cannot be empty."
    if len(text) < 2:
        return text, "Food item name must be at least 2 characters long."
    if len(text) > 80:
        return text, "Food item name must not exceed 80 characters."
    if not NAME_PATTERN.match(text):
        return text, "Name contains invalid characters. Use letters, numbers, spaces, and basic punctuation (- . , & ( ) / '). "
    return text, None


def validate_category(value: Any) -> Tuple[str, Optional[str]]:
    """Validate food category against approved list (case-insensitive match)."""
    if value is None or not str(value).strip():
        return "", "Food category is required."
    raw = str(value).strip()
    lookup = {cat.lower(): cat for cat in FOOD_CATEGORIES}
    matched = lookup.get(raw.lower())
    if not matched:
        return raw, f"Invalid category '{raw}'. Choose from: {', '.join(FOOD_CATEGORIES)}."
    return matched, None


def validate_quantity(value: Any) -> Tuple[Optional[float], Optional[str]]:
    """Validate positive numeric quantity."""
    if value is None or str(value).strip() == "":
        return None, "Quantity is required."
    try:
        qty = float(str(value).strip())
    except (ValueError, TypeError):
        return None, "Quantity must be a valid numeric value."
    if qty != qty or qty in (float("inf"), float("-inf")):
        return None, "Quantity must be a finite number."
    if qty <= 0:
        return None, "Quantity must be greater than zero (negative or zero quantities are not allowed)."
    if qty > 100000:
        return None, "Quantity cannot exceed 100,000."
    # Normalize clean integer representation when whole number
    if qty.is_integer():
        qty = float(int(qty))
    else:
        qty = round(qty, 3)
    return qty, None


def validate_unit(value: Any) -> Tuple[str, Optional[str]]:
    """Validate unit of measurement."""
    if value is None or not str(value).strip():
        return "", "Unit of measurement is required."
    text = re.sub(r"\s+", " ", str(value).strip())
    if not UNIT_PATTERN.match(text):
        return text, "Unit must start with a letter and be 1-20 valid characters (e.g., pcs, kg, L, packs)."
    return text, None


def validate_storage_location(value: Any) -> Tuple[str, Optional[str]]:
    """Validate storage location."""
    if value is None or not str(value).strip():
        return "", "Storage location is required."
    text = re.sub(r"\s+", " ", str(value).strip())
    if not LOCATION_PATTERN.match(text):
        return text, "Storage location contains invalid characters or exceeds 50 characters."
    return text, None


def validate_notes(value: Any) -> Tuple[str, Optional[str]]:
    """Validate optional notes field."""
    if value is None:
        return "", None
    text = str(value).strip()
    if len(text) > 300:
        return text, "Notes must not exceed 300 characters."
    return text, None


def validate_date_pair(
    purchase_date_raw: Any, expiry_date_raw: Any
) -> Tuple[Optional[str], Optional[str], Dict[str, str]]:
    """Validate purchase_date, expiry_date, and ensure expiry >= purchase."""
    errors: Dict[str, str] = {}
    p_date, p_err = parse_iso_date(purchase_date_raw)
    if p_err:
        errors["purchase_date"] = p_err

    e_date, e_err = parse_iso_date(expiry_date_raw)
    if e_err:
        errors["expiry_date"] = e_err

    if p_date and e_date and e_date < p_date:
        errors["expiry_date"] = (
            f"Expiry date ({e_date.isoformat()}) cannot be earlier than purchase date ({p_date.isoformat()})."
        )

    return (
        p_date.isoformat() if p_date else None,
        e_date.isoformat() if e_date else None,
        errors,
    )


def validate_item_payload(
    payload: Dict[str, Any],
    existing_items: Optional[List[PantryItem]] = None,
    ignore_item_id: Optional[str] = None,
    check_duplicates: bool = True,
) -> Tuple[Dict[str, Any], Dict[str, str]]:
    """
    Validate a complete item input payload.

    Returns (cleaned_data, field_errors). If field_errors is empty, cleaned_data is valid.
    """
    errors: Dict[str, str] = {}

    name, err = validate_name(payload.get("name"))
    if err:
        errors["name"] = err

    category, err = validate_category(payload.get("category"))
    if err:
        errors["category"] = err

    quantity, err = validate_quantity(payload.get("quantity"))
    if err:
        errors["quantity"] = err

    unit, err = validate_unit(payload.get("unit"))
    if err:
        errors["unit"] = err

    purchase_iso, expiry_iso, date_errors = validate_date_pair(
        payload.get("purchase_date"), payload.get("expiry_date")
    )
    errors.update(date_errors)

    storage_location, err = validate_storage_location(payload.get("storage_location"))
    if err:
        errors["storage_location"] = err

    notes, err = validate_notes(payload.get("notes", ""))
    if err:
        errors["notes"] = err

    # Duplicate / conflicting record detection (same name + category + expiry_date + location)
    if (
        check_duplicates
        and not errors
        and existing_items is not None
    ):
        for item in existing_items:
            if ignore_item_id and item.item_id == ignore_item_id:
                continue
            if (
                item.name.strip().lower() == name.lower()
                and item.category.strip().lower() == category.lower()
                and item.expiry_date == expiry_iso
                and item.storage_location.strip().lower() == storage_location.lower()
            ):
                errors["duplicate"] = (
                    f"A conflicting record for '{name}' ({category}) in '{storage_location}' "
                    f"expiring on {expiry_iso} already exists (ID: {item.item_id}). Edit the existing item instead."
                )
                break

    cleaned = {
        "name": name,
        "category": category,
        "quantity": quantity if quantity is not None else 0.0,
        "unit": unit,
        "purchase_date": purchase_iso or "",
        "expiry_date": expiry_iso or "",
        "storage_location": storage_location,
        "notes": notes,
    }
    return cleaned, errors


def validate_stored_record(raw: Any) -> Tuple[Optional[PantryItem], Optional[str]]:
    """Validate a record loaded from JSON/CSV storage without crashing."""
    if not isinstance(raw, dict):
        return None, "Record is not a valid dictionary object."

    required = ["item_id", "name", "category", "quantity", "unit", "purchase_date", "expiry_date", "storage_location"]
    for key in required:
        if key not in raw or str(raw.get(key, "")).strip() == "":
            return None, f"Missing required field '{key}'."

    item_id = str(raw["item_id"]).strip()
    cleaned, errors = validate_item_payload(raw, check_duplicates=False)
    if errors:
        first_err = next(iter(errors.values()))
        return None, f"Record '{item_id}' failed schema validation: {first_err}"

    created_at = str(raw.get("created_at") or datetime.now().isoformat(timespec="seconds")).strip()
    return (
        PantryItem(
            item_id=item_id,
            name=cleaned["name"],
            category=cleaned["category"],
            quantity=cleaned["quantity"],
            unit=cleaned["unit"],
            purchase_date=cleaned["purchase_date"],
            expiry_date=cleaned["expiry_date"],
            storage_location=cleaned["storage_location"],
            notes=cleaned["notes"],
            created_at=created_at,
        ),
        None,
    )
