"""Local JSON and CSV persistence with schema validation, fault tolerance, and sample dataset generation."""

from __future__ import annotations

import csv
import json
import os
import shutil
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from backend.models import CSV_FIELDNAMES, PantryItem
from backend.validation import validate_stored_record


BASE_DIR = Path(__file__).resolve().parent.parent
DEFAULT_DATA_DIR = BASE_DIR / "data"


class StorageLoadResult:
    """Encapsulates loaded items along with non-fatal storage warnings."""

    def __init__(self, items: List[PantryItem], warnings: Optional[List[str]] = None):
        self.items = items
        self.warnings = warnings or []


def build_sample_records(reference_date: Optional[date] = None) -> List[PantryItem]:
    """
    Create 36 realistic, varied food pantry records covering:
    - Fresh items (> 7 days)
    - Expiring soon items (1 to 7 days)
    - Expires today items (0 days)
    - Expired items (< 0 days)
    - All 12 food categories, varied units, and boundary cases
    """
    ref = reference_date or date.today()

    def d(offset_days: int) -> str:
        return (ref + timedelta(days=offset_days)).isoformat()

    specs = [
        # Expires Today (boundary: 0 days)
        ("FD-1001", "Organic Whole Milk", "Dairy", 1, "L", -6, 0, "Refrigerator", "Finish today for breakfast"),
        ("FD-1002", "Fresh Baby Spinach", "Vegetables", 250, "g", -4, 0, "Refrigerator", "Pre-washed salad greens"),
        ("FD-1003", "Artisan Sourdough Loaf", "Bakery", 1, "loaves", -3, 0, "Countertop", "Use for toast or croutons"),
        # Expiring Soon (1 to 7 days, including boundary 1 day and 7 days)
        ("FD-1004", "Greek Strained Yogurt", "Dairy", 2, "packs", -10, 1, "Refrigerator", "Boundary: expires tomorrow"),
        ("FD-1005", "Atlantic Salmon Fillet", "Seafood", 0.5, "kg", -2, 1, "Refrigerator", "Cook within 24 hours"),
        ("FD-1006", "Free-Range Chicken Breast", "Meat", 1.2, "kg", -3, 2, "Refrigerator", "Marinate tonight"),
        ("FD-1007", "Strawberries Punnet", "Fruits", 400, "g", -3, 2, "Refrigerator", "Check for moisture"),
        ("FD-1008", "Multigrain Bagels", "Bakery", 6, "pcs", -4, 3, "Pantry Shelf", "Can be frozen if unused"),
        ("FD-1009", "Ripe Hass Avocados", "Fruits", 4, "pcs", -4, 3, "Countertop", "Ready to eat"),
        ("FD-1010", "Fresh Tofu Block", "Other", 2, "packs", -7, 4, "Refrigerator", "Keep submerged in water after opening"),
        ("FD-1011", "Cold-Pressed Orange Juice", "Beverages", 1.5, "L", -5, 4, "Refrigerator", "Opened bottle"),
        ("FD-1012", "Cremini Mushrooms", "Vegetables", 300, "g", -3, 5, "Refrigerator", "Paper bag storage"),
        ("FD-1013", "Ground Lean Turkey", "Meat", 500, "g", -2, 5, "Refrigerator", "Dinner prep"),
        ("FD-1014", "Ricotta Cheese Tub", "Dairy", 250, "g", -8, 6, "Refrigerator", "For pasta bake"),
        ("FD-1015", "Fresh Blueberries", "Fruits", 200, "g", -3, 7, "Refrigerator", "Boundary: exactly 7 days remaining"),
        # Expired items (negative days)
        ("FD-1016", "Unpasteurized Apple Cider", "Beverages", 1, "bottles", -14, -1, "Refrigerator", "Boundary: expired yesterday"),
        ("FD-1017", "Cilantro Bunch", "Vegetables", 1, "bunches", -9, -2, "Refrigerator", "Check for wilting"),
        ("FD-1018", "Heavy Whipping Cream", "Dairy", 500, "mL", -15, -4, "Refrigerator", "Past use-by date; discard"),
        ("FD-1019", "Deli Sliced Turkey", "Meat", 200, "g", -12, -5, "Refrigerator", "Overdue refrigerated meat"),
        # Fresh items (> 7 days, including boundary 8 days)
        ("FD-1020", "Large Brown Eggs", "Dairy", 12, "pcs", -5, 8, "Refrigerator", "Boundary: 8 days remaining"),
        ("FD-1021", "Fuji Apples", "Fruits", 2, "kg", -4, 14, "Refrigerator", "Crisper drawer"),
        ("FD-1022", "Carrots Bag", "Vegetables", 1, "kg", -5, 18, "Refrigerator", "Root vegetable storage"),
        ("FD-1023", "Sharp Cheddar Block", "Dairy", 400, "g", -10, 25, "Refrigerator", "Unopened vacuum pack"),
        ("FD-1024", "Yellow Onions", "Vegetables", 1.5, "kg", -7, 30, "Dry Cabinet", "Keep away from potatoes"),
        ("FD-1025", "Russet Potatoes", "Vegetables", 2.5, "kg", -6, 35, "Cellar", "Cool dark storage"),
        ("FD-1026", "Frozen Wild Shrimp", "Seafood", 750, "g", -14, 90, "Freezer", "Keep at -18C"),
        ("FD-1027", "Frozen Edamame Pods", "Frozen Food", 2, "packs", -20, 120, "Freezer", "Steam before serving"),
        ("FD-1028", "Frozen Mixed Berries", "Frozen Food", 1, "kg", -15, 150, "Freezer", "Smoothie stock"),
        ("FD-1029", "Rolled Oats", "Grains", 1.5, "kg", -20, 180, "Pantry Shelf", "Airtight glass jar"),
        ("FD-1030", "Jasmine White Rice", "Grains", 5, "kg", -30, 320, "Pantry Shelf", "Dry bulk staple"),
        ("FD-1031", "Whole Wheat Penne", "Grains", 3, "boxes", -25, 240, "Pantry Shelf", "Unopened boxes"),
        ("FD-1032", "San Marzano Crushed Tomatoes", "Canned Food", 6, "cans", -45, 420, "Dry Cabinet", "Pantry tomato sauce base"),
        ("FD-1033", "Canned Chickpeas", "Canned Food", 4, "cans", -30, 500, "Dry Cabinet", "Low sodium"),
        ("FD-1034", "Roasted Salted Almonds", "Snacks", 500, "g", -15, 95, "Pantry Shelf", "Resealable pouch"),
        ("FD-1035", "Dark Chocolate Bars", "Snacks", 3, "packs", -10, 160, "Pantry Shelf", "70% cocoa"),
        ("FD-1036", "Sparkling Mineral Water", "Beverages", 12, "bottles", -12, 210, "Cellar", "Case pack"),
        ("FD-1037", "Extra Virgin Olive Oil", "Other", 750, "mL", -30, 270, "Dry Cabinet", "Dark glass bottle"),
        ("FD-1038", "Raw Wildflower Honey", "Other", 1, "jars", -60, 730, "Pantry Shelf", "Store at room temp"),
    ]

    records: List[PantryItem] = []
    now_iso = datetime.now().isoformat(timespec="seconds")
    for item_id, name, cat, qty, unit, p_off, e_off, loc, notes in specs:
        records.append(
            PantryItem(
                item_id=item_id,
                name=name,
                category=cat,
                quantity=float(qty),
                unit=unit,
                purchase_date=d(p_off),
                expiry_date=d(e_off),
                storage_location=loc,
                notes=notes,
                created_at=now_iso,
            )
        )
    return records


class PantryStorage:
    """Manages persistent JSON and CSV storage for pantry items."""

    def __init__(self, data_dir: Optional[Path] = None):
        self.data_dir = Path(data_dir) if data_dir else DEFAULT_DATA_DIR
        self.json_path = self.data_dir / "pantry_data.json"
        self.csv_path = self.data_dir / "pantry_data.csv"
        self.sample_csv_path = self.data_dir / "sample_dataset.csv"
        self.sample_json_path = self.data_dir / "sample_dataset.json"
        self.ensure_initialized()

    def ensure_initialized(self) -> None:
        """Initialize data directory, sample dataset files, and clean primary files if missing."""
        self.data_dir.mkdir(parents=True, exist_ok=True)

        # Ensure sample dataset files always exist for demo & CSV import testing
        if not self.sample_csv_path.exists() or not self.sample_json_path.exists():
            sample_items = build_sample_records()
            if not self.sample_json_path.exists():
                self._write_json_atomic(self.sample_json_path, sample_items)
            if not self.sample_csv_path.exists():
                self._write_csv_atomic(self.sample_csv_path, sample_items)

        # First initialization: seed primary storage ONLY if neither JSON nor CSV exists yet
        if not self.json_path.exists() and not self.csv_path.exists():
            initial_items = build_sample_records()
            self._write_json_atomic(self.json_path, initial_items)
            self._write_csv_atomic(self.csv_path, initial_items)
        elif not self.json_path.exists() and self.csv_path.exists():
            # Recover JSON from CSV if JSON was removed
            csv_res = self._read_csv(self.csv_path)
            self._write_json_atomic(self.json_path, csv_res.items)
        elif self.json_path.exists() and not self.csv_path.exists():
            # Recover CSV from JSON if valid
            json_res = self._read_json(self.json_path)
            if json_res.items or not json_res.warnings:
                self._write_csv_atomic(self.csv_path, json_res.items)

    def load_items(self) -> StorageLoadResult:
        """
        Load pantry items safely from JSON (primary) with fallback to CSV if JSON is corrupted.
        Corrupted files are backed up rather than silently destroyed.
        """
        warnings: List[str] = []

        if self.json_path.exists():
            json_result = self._read_json(self.json_path)
            warnings.extend(json_result.warnings)
            if json_result.items or not json_result.warnings:
                return StorageLoadResult(json_result.items, warnings)

            # JSON was corrupted or unreadable; try CSV fallback without destroying corrupted JSON
            if self.csv_path.exists():
                csv_result = self._read_csv(self.csv_path)
                warnings.extend(csv_result.warnings)
                if csv_result.items:
                    warnings.append(
                        "Recovered pantry records from backup CSV file because JSON storage had errors."
                    )
                    return StorageLoadResult(csv_result.items, warnings)

            return StorageLoadResult([], warnings)

        if self.csv_path.exists():
            csv_result = self._read_csv(self.csv_path)
            return csv_result

        # Initialize clean empty templates if both missing
        self._write_json_atomic(self.json_path, [])
        self._write_csv_atomic(self.csv_path, [])
        return StorageLoadResult([], ["Initialized fresh empty pantry storage files."])

    def save_items(self, items: List[PantryItem]) -> None:
        """Persist items atomically to both JSON and CSV storage."""
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._write_json_atomic(self.json_path, items)
        self._write_csv_atomic(self.csv_path, items)

    def _backup_corrupted_file(self, path: Path) -> Optional[Path]:
        """Preserve corrupted file with timestamped .corrupted backup."""
        try:
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup = path.with_name(f"{path.stem}.corrupted_{stamp}{path.suffix}")
            shutil.copy2(path, backup)
            return backup
        except OSError:
            return None

    def _read_json(self, path: Path) -> StorageLoadResult:
        warnings: List[str] = []
        try:
            with path.open("r", encoding="utf-8") as fh:
                raw_data = json.load(fh)
        except FileNotFoundError:
            return StorageLoadResult([], [f"Storage file '{path.name}' was not found."])
        except PermissionError:
            return StorageLoadResult([], [f"Permission denied reading '{path.name}'."])
        except json.JSONDecodeError as exc:
            backup = self._backup_corrupted_file(path)
            backup_note = f" A backup was preserved at '{backup.name}'." if backup else ""
            return StorageLoadResult(
                [],
                [f"Corrupted JSON in '{path.name}' (line {exc.lineno}, col {exc.colno}).{backup_note}"],
            )
        except OSError as exc:
            return StorageLoadResult([], [f"Error reading '{path.name}': {exc}"])

        if isinstance(raw_data, dict) and "items" in raw_data:
            records_raw = raw_data["items"]
        elif isinstance(raw_data, list):
            records_raw = raw_data
        else:
            backup = self._backup_corrupted_file(path)
            backup_note = f" Backup saved to '{backup.name}'." if backup else ""
            return StorageLoadResult(
                [],
                [f"Invalid JSON structure in '{path.name}': expected a list or object with 'items'.{backup_note}"],
            )

        if not isinstance(records_raw, list):
            return StorageLoadResult([], [f"Invalid 'items' field in '{path.name}'."])

        valid_items: List[PantryItem] = []
        for idx, rec in enumerate(records_raw, start=1):
            item, err = validate_stored_record(rec)
            if err or item is None:
                warnings.append(f"Skipped invalid JSON record #{idx}: {err}")
            else:
                valid_items.append(item)

        return StorageLoadResult(valid_items, warnings)

    def _read_csv(self, path: Path) -> StorageLoadResult:
        warnings: List[str] = []
        try:
            with path.open("r", encoding="utf-8", newline="") as fh:
                reader = csv.DictReader(fh)
                if reader.fieldnames is None:
                    return StorageLoadResult([], [f"CSV file '{path.name}' is empty or missing headers."])
                missing_cols = [
                    col for col in CSV_FIELDNAMES if col not in ("notes", "created_at") and col not in reader.fieldnames
                ]
                if missing_cols:
                    return StorageLoadResult(
                        [],
                        [f"CSV file '{path.name}' is missing required headers: {', '.join(missing_cols)}."],
                    )
                valid_items: List[PantryItem] = []
                for idx, row in enumerate(reader, start=2):
                    item, err = validate_stored_record(row)
                    if err or item is None:
                        warnings.append(f"Skipped invalid CSV row {idx}: {err}")
                    else:
                        valid_items.append(item)
                return StorageLoadResult(valid_items, warnings)
        except FileNotFoundError:
            return StorageLoadResult([], [f"CSV file '{path.name}' not found."])
        except PermissionError:
            return StorageLoadResult([], [f"Permission denied reading '{path.name}'."])
        except (csv.Error, UnicodeDecodeError) as exc:
            return StorageLoadResult([], [f"Malformed CSV in '{path.name}': {exc}"])

    def _write_json_atomic(self, path: Path, items: List[PantryItem]) -> None:
        tmp_path = path.with_suffix(".json.tmp")
        payload = {
            "schema_version": 1,
            "updated_at": datetime.now().isoformat(timespec="seconds"),
            "item_count": len(items),
            "items": [item.to_dict() for item in items],
        }
        try:
            with tmp_path.open("w", encoding="utf-8") as fh:
                json.dump(payload, fh, indent=2, ensure_ascii=False)
            os.replace(tmp_path, path)
        except PermissionError as exc:
            raise PermissionError(f"Cannot write JSON storage '{path.name}': {exc}") from exc

    def _write_csv_atomic(self, path: Path, items: List[PantryItem]) -> None:
        tmp_path = path.with_suffix(".csv.tmp")
        try:
            with tmp_path.open("w", encoding="utf-8", newline="") as fh:
                writer = csv.DictWriter(fh, fieldnames=CSV_FIELDNAMES)
                writer.writeheader()
                for item in items:
                    writer.writerow(item.to_dict())
            os.replace(tmp_path, path)
        except PermissionError as exc:
            raise PermissionError(f"Cannot write CSV storage '{path.name}': {exc}") from exc
