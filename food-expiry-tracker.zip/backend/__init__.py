"""Backend package for Food Expiry Tracker (StudentLife Hack Project #62)."""
