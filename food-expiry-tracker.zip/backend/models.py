"""Data models, domain constants, and schema definitions for Food Expiry Tracker."""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any, Dict, List, Optional


FOOD_CATEGORIES: List[str] = [
    "Fruits",
    "Vegetables",
    "Dairy",
    "Meat",
    "Seafood",
    "Grains",
    "Bakery",
    "Beverages",
    "Frozen Food",
    "Canned Food",
    "Snacks",
    "Other",
]

MEASUREMENT_UNITS: List[str] = [
    "pcs",
    "kg",
    "g",
    "L",
    "mL",
    "packs",
    "cans",
    "bottles",
    "boxes",
    "loaves",
    "bunches",
    "jars",
]

STORAGE_LOCATIONS: List[str] = [
    "Refrigerator",
    "Freezer",
    "Pantry Shelf",
    "Dry Cabinet",
    "Countertop",
    "Cellar",
    "Other",
]

EXPIRY_STATUS_FRESH = "Fresh"
EXPIRY_STATUS_EXPIRING_SOON = "Expiring Soon"
EXPIRY_STATUS_EXPIRES_TODAY = "Expires Today"
EXPIRY_STATUS_EXPIRED = "Expired"

ALL_EXPIRY_STATUSES: List[str] = [
    EXPIRY_STATUS_EXPIRED,
    EXPIRY_STATUS_EXPIRES_TODAY,
    EXPIRY_STATUS_EXPIRING_SOON,
    EXPIRY_STATUS_FRESH,
]

CSV_FIELDNAMES: List[str] = [
    "item_id",
    "name",
    "category",
    "quantity",
    "unit",
    "purchase_date",
    "expiry_date",
    "storage_location",
    "notes",
    "created_at",
]


@dataclass
class PantryItem:
    """Represents a single food pantry record."""

    item_id: str
    name: str
    category: str
    quantity: float
    unit: str
    purchase_date: str  # YYYY-MM-DD
    expiry_date: str    # YYYY-MM-DD
    storage_location: str
    notes: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))

    def to_dict(self) -> Dict[str, Any]:
        """Serialize item to a JSON/CSV-friendly dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PantryItem":
        """Construct a PantryItem from a raw dictionary."""
        return cls(
            item_id=str(data.get("item_id", "")).strip(),
            name=str(data.get("name", "")).strip(),
            category=str(data.get("category", "")).strip(),
            quantity=float(data.get("quantity", 0)),
            unit=str(data.get("unit", "pcs")).strip(),
            purchase_date=str(data.get("purchase_date", "")).strip(),
            expiry_date=str(data.get("expiry_date", "")).strip(),
            storage_location=str(data.get("storage_location", "Pantry Shelf")).strip(),
            notes=str(data.get("notes", "") or "").strip(),
            created_at=str(data.get("created_at", "") or datetime.now().isoformat(timespec="seconds")).strip(),
        )


@dataclass
class EnrichedPantryItem:
    """Pantry item enriched with live, dynamically calculated expiry fields."""

    item: PantryItem
    days_remaining: int
    status: str
    is_critical: bool
    anomaly_warning: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        base = self.item.to_dict()
        base.update(
            {
                "days_remaining": self.days_remaining,
                "status": self.status,
                "is_critical": self.is_critical,
                "anomaly_warning": self.anomaly_warning,
            }
        )
        return base
