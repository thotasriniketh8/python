"""Keyword search, combined filtering, sorting, and pagination in Python."""

from __future__ import annotations

import math
from typing import Any, Dict, List, Optional

from backend.models import EnrichedPantryItem


def filter_and_search(
    items: List[EnrichedPantryItem],
    query: str = "",
    category: str = "",
    status: str = "",
    location: str = "",
    expiry_before: str = "",
    expiry_after: str = "",
    sort_by: str = "expiry_date",
    sort_order: str = "asc",
) -> List[EnrichedPantryItem]:
    """
    Filter and sort pantry items using Python backend logic.
    Supports combined keyword (name, category, storage location, notes, ID) and attribute filters.
    """
    q = (query or "").strip().lower()
    cat = (category or "").strip().lower()
    stat = (status or "").strip().lower()
    loc = (location or "").strip().lower()
    exp_before = (expiry_before or "").strip()
    exp_after = (expiry_after or "").strip()

    filtered: List[EnrichedPantryItem] = []
    for e in items:
        item = e.item
        if q:
            haystack = " ".join(
                [
                    item.item_id,
                    item.name,
                    item.category,
                    item.storage_location,
                    item.notes,
                    e.status,
                ]
            ).lower()
            if q not in haystack:
                continue

        if cat and cat != "all" and item.category.lower() != cat:
            continue

        if stat and stat != "all" and e.status.lower() != stat:
            continue

        if loc and loc != "all" and item.storage_location.lower() != loc:
            continue

        if exp_after and item.expiry_date < exp_after:
            continue

        if exp_before and item.expiry_date > exp_before:
            continue

        filtered.append(e)

    reverse = (sort_order or "asc").strip().lower() == "desc"
    sort_key = (sort_by or "expiry_date").strip().lower()

    if sort_key == "name":
        filtered.sort(key=lambda e: (e.item.name.lower(), e.item.expiry_date), reverse=reverse)
    elif sort_key == "quantity":
        filtered.sort(key=lambda e: (e.item.quantity, e.item.name.lower()), reverse=reverse)
    elif sort_key == "category":
        filtered.sort(key=lambda e: (e.item.category.lower(), e.item.expiry_date), reverse=reverse)
    elif sort_key == "purchase_date":
        filtered.sort(key=lambda e: (e.item.purchase_date, e.item.name.lower()), reverse=reverse)
    elif sort_key == "days_remaining":
        filtered.sort(key=lambda e: (e.days_remaining, e.item.name.lower()), reverse=reverse)
    else:  # default expiry_date
        filtered.sort(key=lambda e: (e.item.expiry_date, e.item.name.lower()), reverse=reverse)

    return filtered


def paginate_items(
    items: List[EnrichedPantryItem], page: int = 1, per_page: int = 10
) -> Dict[str, Any]:
    """Paginate a list of enriched pantry items."""
    safe_per_page = max(1, min(100, int(per_page)))
    total = len(items)
    total_pages = max(1, math.ceil(total / safe_per_page))
    current_page = max(1, min(int(page), total_pages))
    start = (current_page - 1) * safe_per_page
    end = start + safe_per_page

    return {
        "items": items[start:end],
        "page": current_page,
        "per_page": safe_per_page,
        "total": total,
        "total_pages": total_pages,
        "has_prev": current_page > 1,
        "has_next": current_page < total_pages,
        "start_index": start + 1 if total > 0 else 0,
        "end_index": min(end, total),
    }
