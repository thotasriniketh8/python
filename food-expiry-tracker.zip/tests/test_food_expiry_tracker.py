"""Comprehensive automated test suite covering all mandatory requirements (Section 14)."""

from __future__ import annotations

import json
from datetime import date, timedelta
from pathlib import Path

import pytest

from app import create_app
from backend.analytics import compute_analytics_summary, generate_all_charts
from backend.expiry_engine import (
    calculate_days_remaining,
    classify_expiry_status,
)
from backend.import_export import import_csv_text
from backend.inventory import InventoryService
from backend.models import (
    EXPIRY_STATUS_EXPIRED,
    EXPIRY_STATUS_EXPIRES_TODAY,
    EXPIRY_STATUS_EXPIRING_SOON,
    EXPIRY_STATUS_FRESH,
)
from backend.report_generator import (
    generate_csv_report,
    generate_markdown_report,
    generate_text_report,
)
from backend.search import filter_and_search
from backend.storage import PantryStorage


def iso_offset(days: int) -> str:
    return (date.today() + timedelta(days=days)).isoformat()


@pytest.fixture
def isolated_service(tmp_path: Path) -> InventoryService:
    """Create an InventoryService backed by an isolated empty temporary storage directory."""
    data_dir = tmp_path / "data"
    service = InventoryService(data_dir=data_dir)
    # Start clean for deterministic unit tests
    service.storage.save_items([])
    return service


def test_add_valid_item_and_persistence_across_restart(tmp_path: Path):
    data_dir = tmp_path / "data"
    service1 = InventoryService(data_dir=data_dir)
    service1.storage.save_items([])

    created, errors = service1.add_item(
        {
            "name": "Organic Whole Milk",
            "category": "Dairy",
            "quantity": "2",
            "unit": "L",
            "purchase_date": iso_offset(-1),
            "expiry_date": iso_offset(10),
            "storage_location": "Refrigerator",
            "notes": "Fresh carton",
        }
    )
    assert errors == {}
    assert created is not None
    assert created.status == EXPIRY_STATUS_FRESH

    # Simulate application restart with fresh InventoryService instance
    service2 = InventoryService(data_dir=data_dir)
    loaded, warnings = service2.load_all()
    assert warnings == []
    assert len(loaded) == 1
    assert loaded[0].item.name == "Organic Whole Milk"
    assert loaded[0].item.item_id == created.item.item_id


def test_validation_rejects_empty_name_negative_qty_invalid_dates_and_expiry_before_purchase(
    isolated_service: InventoryService,
):
    # Empty name
    item, errs = isolated_service.add_item(
        {
            "name": "   ",
            "category": "Dairy",
            "quantity": "1",
            "unit": "L",
            "purchase_date": iso_offset(0),
            "expiry_date": iso_offset(5),
            "storage_location": "Refrigerator",
        }
    )
    assert item is None
    assert "name" in errs

    # Negative quantity
    item, errs = isolated_service.add_item(
        {
            "name": "Eggs",
            "category": "Dairy",
            "quantity": "-5",
            "unit": "pcs",
            "purchase_date": iso_offset(0),
            "expiry_date": iso_offset(5),
            "storage_location": "Refrigerator",
        }
    )
    assert item is None
    assert "quantity" in errs

    # Invalid date format
    item, errs = isolated_service.add_item(
        {
            "name": "Eggs",
            "category": "Dairy",
            "quantity": "12",
            "unit": "pcs",
            "purchase_date": "2026/99/99",
            "expiry_date": iso_offset(5),
            "storage_location": "Refrigerator",
        }
    )
    assert item is None
    assert "purchase_date" in errs

    # Expiry date earlier than purchase date
    item, errs = isolated_service.add_item(
        {
            "name": "Eggs",
            "category": "Dairy",
            "quantity": "12",
            "unit": "pcs",
            "purchase_date": iso_offset(5),
            "expiry_date": iso_offset(2),
            "storage_location": "Refrigerator",
        }
    )
    assert item is None
    assert "expiry_date" in errs


def test_expiry_boundary_classifications(isolated_service: InventoryService):
    # Expiring today (0 days)
    today_item, errs = isolated_service.add_item(
        {
            "name": "Fresh Spinach",
            "category": "Vegetables",
            "quantity": "1",
            "unit": "packs",
            "purchase_date": iso_offset(-3),
            "expiry_date": iso_offset(0),
            "storage_location": "Refrigerator",
        }
    )
    assert errs == {}
    assert today_item is not None
    assert today_item.days_remaining == 0
    assert today_item.status == EXPIRY_STATUS_EXPIRES_TODAY

    # Expiring tomorrow (1 day)
    tmrw_item, errs = isolated_service.add_item(
        {
            "name": "Greek Yogurt",
            "category": "Dairy",
            "quantity": "2",
            "unit": "packs",
            "purchase_date": iso_offset(-5),
            "expiry_date": iso_offset(1),
            "storage_location": "Refrigerator",
        }
    )
    assert errs == {}
    assert tmrw_item is not None
    assert tmrw_item.days_remaining == 1
    assert tmrw_item.status == EXPIRY_STATUS_EXPIRING_SOON

    # Already expired (-2 days)
    exp_item, errs = isolated_service.add_item(
        {
            "name": "Apple Cider",
            "category": "Beverages",
            "quantity": "1",
            "unit": "bottles",
            "purchase_date": iso_offset(-10),
            "expiry_date": iso_offset(-2),
            "storage_location": "Refrigerator",
        }
    )
    assert errs == {}
    assert exp_item is not None
    assert exp_item.days_remaining == -2
    assert exp_item.status == EXPIRY_STATUS_EXPIRED
    assert calculate_days_remaining(iso_offset(8)) == 8
    assert classify_expiry_status(8) == EXPIRY_STATUS_FRESH


def test_search_filter_edit_and_delete(isolated_service: InventoryService):
    a, _ = isolated_service.add_item(
        {
            "name": "Fuji Apples",
            "category": "Fruits",
            "quantity": "3",
            "unit": "kg",
            "purchase_date": iso_offset(-2),
            "expiry_date": iso_offset(12),
            "storage_location": "Refrigerator",
        }
    )
    b, _ = isolated_service.add_item(
        {
            "name": "Jasmine Rice",
            "category": "Grains",
            "quantity": "5",
            "unit": "kg",
            "purchase_date": iso_offset(-10),
            "expiry_date": iso_offset(200),
            "storage_location": "Pantry Shelf",
        }
    )
    assert a is not None and b is not None

    all_items, _ = isolated_service.load_all()
    by_kw = filter_and_search(all_items, query="apple")
    assert len(by_kw) == 1
    assert by_kw[0].item.item_id == a.item.item_id

    by_cat = filter_and_search(all_items, category="Grains")
    assert len(by_cat) == 1
    assert by_cat[0].item.item_id == b.item.item_id

    # Edit
    updated, errs = isolated_service.update_item(
        a.item.item_id,
        {
            "name": "Honeycrisp Apples",
            "category": "Fruits",
            "quantity": "4",
            "unit": "kg",
            "purchase_date": a.item.purchase_date,
            "expiry_date": a.item.expiry_date,
            "storage_location": "Crisper Drawer",
            "notes": "Updated variety",
        },
    )
    assert errs == {}
    assert updated is not None
    assert updated.item.name == "Honeycrisp Apples"
    assert updated.item.quantity == 4.0

    # Delete
    ok, deleted = isolated_service.delete_item(b.item.item_id)
    assert ok is True
    assert deleted is not None
    remaining, _ = isolated_service.load_all()
    assert len(remaining) == 1


def test_csv_import_valid_and_mixed_invalid_rows(isolated_service: InventoryService):
    valid_csv = (
        "name,category,quantity,unit,purchase_date,expiry_date,storage_location,notes\n"
        f"Rolled Oats,Grains,2,kg,{iso_offset(-5)},{iso_offset(120)},Pantry Shelf,Bulk oats\n"
        f"Almond Milk,Beverages,1.5,L,{iso_offset(-1)},{iso_offset(15)},Refrigerator,Unsweetened\n"
    )
    res_valid = import_csv_text(valid_csv, isolated_service)
    assert res_valid.success is True
    assert res_valid.imported_count == 2
    assert res_valid.failed_count == 0

    mixed_csv = (
        "name,category,quantity,unit,purchase_date,expiry_date,storage_location,notes\n"
        f"Canned Beans,Canned Food,4,cans,{iso_offset(-10)},{iso_offset(300)},Dry Cabinet,Valid row\n"
        f",Dairy,1,L,{iso_offset(-1)},{iso_offset(5)},Refrigerator,Missing name\n"
        f"Bad Qty Item,Snacks,-3,packs,{iso_offset(-1)},{iso_offset(5)},Pantry Shelf,Negative qty\n"
        f"Bad Date Item,Fruits,2,kg,{iso_offset(10)},{iso_offset(2)},Countertop,Expiry before purchase\n"
    )
    res_mixed = import_csv_text(mixed_csv, isolated_service)
    assert res_mixed.success is True
    assert res_mixed.imported_count == 1
    assert res_mixed.failed_count == 3
    assert len(res_mixed.row_errors) == 3

    all_items, _ = isolated_service.load_all()
    assert len(all_items) == 3


def test_report_exports_and_empty_analytics(tmp_path: Path, isolated_service: InventoryService):
    # Empty dataset analytics must not crash
    empty_items, _ = isolated_service.load_all()
    empty_summary = compute_analytics_summary(empty_items)
    assert empty_summary["is_empty"] is True
    assert empty_summary["total_records"] == 0

    charts_dir = tmp_path / "charts"
    chart_map = generate_all_charts(empty_items, charts_dir=charts_dir)
    for fname in chart_map.values():
        assert (charts_dir / fname).is_file()

    # Add items and export all three formats
    isolated_service.add_item(
        {
            "name": "Cheddar Cheese",
            "category": "Dairy",
            "quantity": "1",
            "unit": "packs",
            "purchase_date": iso_offset(-3),
            "expiry_date": iso_offset(20),
            "storage_location": "Refrigerator",
        }
    )
    items, _ = isolated_service.load_all()
    reports_dir = tmp_path / "reports"
    md_path = generate_markdown_report(items, output_dir=reports_dir)
    txt_path = generate_text_report(items, output_dir=reports_dir)
    csv_path = generate_csv_report(items, output_dir=reports_dir)

    assert md_path.is_file() and "Cheddar Cheese" in md_path.read_text(encoding="utf-8")
    assert txt_path.is_file() and "Cheddar Cheese" in txt_path.read_text(encoding="utf-8")
    assert csv_path.is_file() and "Cheddar Cheese" in csv_path.read_text(encoding="utf-8")


def test_corrupted_json_recovery_preserves_backup(tmp_path: Path):
    data_dir = tmp_path / "data"
    storage = PantryStorage(data_dir=data_dir)
    # Write corrupted JSON while CSV remains intact
    storage.json_path.write_text("{broken json!!!", encoding="utf-8")

    result = storage.load_items()
    assert len(result.items) >= 30
    assert any("Corrupted JSON" in w for w in result.warnings)
    backups = list(data_dir.glob("pantry_data.corrupted_*.json"))
    assert len(backups) == 1


def test_flask_web_and_backend_consistency(tmp_path: Path):
    data_dir = tmp_path / "data"
    flask_app = create_app(data_dir=data_dir)
    flask_app.config["TESTING"] = True
    client = flask_app.test_client()

    # Dashboard renders seeded sample records
    resp = client.get("/")
    assert resp.status_code == 200
    assert b"Total Pantry Items" in resp.data

    # Invalid POST returns validation error instead of 500
    bad_resp = client.post(
        "/add",
        data={
            "name": "",
            "category": "Dairy",
            "quantity": "-2",
            "unit": "L",
            "purchase_date": iso_offset(5),
            "expiry_date": iso_offset(1),
            "storage_location": "Refrigerator",
        },
        follow_redirects=True,
    )
    assert bad_resp.status_code == 200
    assert b"Food item name cannot be empty" in bad_resp.data

    # Analytics, Inventory, Alerts, Reports & Import render cleanly
    assert client.get("/inventory").status_code == 200
    assert client.get("/analytics").status_code == 200
    assert client.get("/alerts").status_code == 200
    assert client.get("/reports").status_code == 200
    assert client.get("/import").status_code == 200

    # Valid POST /add redirects to /inventory and renders item
    good_resp = client.post(
        "/add",
        data={
            "name": "Flask Test Pear",
            "category": "Fruits",
            "quantity": "4",
            "unit": "pcs",
            "purchase_date": iso_offset(0),
            "expiry_date": iso_offset(6),
            "storage_location": "Refrigerator",
            "notes": "Integration check",
        },
        follow_redirects=True,
    )
    assert good_resp.status_code == 200
    assert b"Flask Test Pear" in good_resp.data
