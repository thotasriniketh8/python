# Food Expiry Tracker — StudentLife Hack Project #62

**Domain:** Food & Agriculture  
**Primary Language:** Python 3.10+ (Flask, Pandas, NumPy, Matplotlib)

## Problem Statement

Manually tracking pantry food items and expiration dates frequently leads to calculation errors, misplaced records, delayed status updates, and avoidable household or campus food waste. **Food Expiry Tracker** eliminates manual tracking overhead by centralizing pantry item recording, defensive input validation, live `datetime`-based expiry classification, dual JSON/CSV persistence, executive analytics, and multi-format report exports across both a Python CLI and a Flask web application.

## Project Objectives

- Maintain **Python** as the core computational engine for all expiry math, validation, search, analytics, charting, and report generation.
- Provide a **dual-interface architecture** where the interactive terminal CLI (`main.py`) and Flask web dashboard (`app.py`) share the exact same backend modules and persistent storage.
- Guarantee **fault tolerance** through centralized defensive validation, atomic JSON/CSV writes, and non-destructive recovery from corrupted files.
- Deliver **executive insights** using **Pandas**, **NumPy**, and **Matplotlib** charts alongside Markdown, Plain Text, and CSV exports.

## Features

- **Interactive Terminal CLI (`main.py`)**: Branded welcome screen, continuous 9-option navigation menu, repeated defensive input prompts, fixed-width paginated tables, search, analytics summary, report export, and CSV import.
- **Flask Web Workspace (`app.py`)**:
  - **Dashboard**: 6 dynamically computed KPIs (Total Items, Fresh, Expiring Soon, Expires Today, Expired, Total Quantity), critical warnings, upcoming expirations, category distribution, and recent additions.
  - **Inventory Management**: Keyword search, category/status filters, multi-field sorting, pagination, edit, and safe delete confirmation.
  - **Add / Edit Item**: Authoritative Python server-side validation with field-specific errors and client-side date hints.
  - **Expiry Alerts**: Urgent-first breakdown (Expired, Expires Today, Expiring Within 7 Days, Anomaly Flags) with category and date filters.
  - **Analytics & Charts**: Pandas & NumPy summaries with 4 Python-generated Matplotlib PNG charts (doughnut category chart, expiry status bar chart, upcoming expiry overview, and shelf-life horizon).
  - **Export Reports**: One-click generation and download of `.md`, `.txt`, and `.csv` reports.
  - **Bulk CSV Import**: Header, type, date, and duplicate validation that preserves valid rows even when invalid rows are logged.

## Technology Stack

- **Backend & Logic**: Python 3.10+, `datetime`, `csv`, `json`, `math`, `re`, `dataclasses`
- **Web Framework**: Flask (Jinja2 HTML5 templates)
- **Data & Visualization**: Pandas, NumPy, Matplotlib (`Agg` headless backend)
- **Frontend**: HTML5, CSS3, minimal vanilla JavaScript for UI interactions
- **Testing**: `pytest`

## Project Directory Structure

```text
food-expiry-tracker/
├── app.py                        # Flask web application entry point
├── main.py                       # Interactive menu-driven Python CLI
├── requirements.txt              # Python dependencies
├── README.md                     # Documentation
├── backend/
│   ├── __init__.py
│   ├── models.py                 # PantryItem & EnrichedPantryItem dataclasses
│   ├── validation.py             # Centralized regex, numeric, date & duplicate checks
│   ├── expiry_engine.py          # Live datetime calculations & anomaly detection
│   ├── storage.py                # Dual JSON & CSV persistence + sample generator
│   ├── inventory.py              # Shared CRUD & dashboard summary service
│   ├── search.py                 # Keyword search, filtering, sorting & pagination
│   ├── analytics.py              # Pandas, NumPy & Matplotlib charts
│   ├── import_export.py          # Bulk CSV dataset validation & import
│   └── report_generator.py       # Markdown, Plain Text & CSV report builders
├── data/
│   ├── pantry_data.json          # Primary JSON persistence
│   ├── pantry_data.csv           # Synchronized CSV persistence
│   ├── sample_dataset.csv        # 38-record sample dataset (CSV)
│   └── sample_dataset.json       # 38-record sample dataset (JSON)
├── reports/
│   ├── markdown/
│   ├── text/
│   ├── csv/
│   └── charts/
├── templates/                    # Jinja2 HTML5 templates
├── static/                       # CSS3 & lightweight frontend JS
└── tests/
    └── test_food_expiry_tracker.py
```

## Installation & Setup

### Linux / macOS
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### Windows (Command Prompt / PowerShell)
```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## Launching the Application

### 1. Launch the Interactive Terminal CLI
```bash
python main.py
```
*(On Windows: `python main.py` inside your activated `.venv`.)*

### 2. Launch the Flask Web Application
```bash
python app.py
```
Then open `http://127.0.0.1:5000` in your browser.  
*(In AI Studio preview environments, `npm run dev` runs `server.ts` on port `3000` and proxies all requests directly to `python3 app.py`.)*

## How Data Is Stored & Sample Dataset

- Records are stored simultaneously in `data/pantry_data.json` and `data/pantry_data.csv`.
- Expiry statuses (**Fresh**, **Expiring Soon**, **Expires Today**, **Expired**) are never frozen in storage; they are recalculated dynamically using Python `datetime.date.today()` every time the CLI or web app loads records.
- On initial startup (when storage files do not yet exist), a realistic **38-item sample dataset** (`data/sample_dataset.json` and `data/sample_dataset.csv`) is seeded covering all 12 food categories, boundary cases (0 days, 1 day, 7 days, 8 days, -1 day), and varied units.
- Existing user records are never overwritten on restart. If JSON storage becomes corrupted, a timestamped backup is preserved and records are recovered from CSV automatically.

## Running Tests

```bash
pytest -v
```

## Hackathon Demonstration Flow

1. Run `python main.py` to display the branded terminal welcome screen and 9-option menu.
2. Select `1` to add an item; enter invalid inputs (empty name, negative quantity, expiry before purchase) to demonstrate defensive validation, then enter valid inputs to save.
3. Open the Flask web dashboard (`/`), inspect dynamically updated KPIs, check **Expiry Alerts** (`/alerts`), run keyword/category filters on **Inventory** (`/inventory`), open **Analytics** (`/analytics`) to view Pandas/NumPy summaries and Matplotlib charts, and export a report from **Reports** (`/reports`).
4. Restart the application and verify all newly added items remain persisted across both CLI and web views.

## Future Enhancements

- Optional desktop GUI using `tkinter` or rich terminal UI using `textual` built atop the existing `backend/` package.
- Barcode / receipt OCR scanner integration feeding directly into `backend.validation`.
- Multi-household pantry sharing and configurable email/push expiry reminders.
