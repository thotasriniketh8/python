"""Flask web application for Food Expiry Tracker (StudentLife Hack Project #62)."""

from __future__ import annotations

import os
import secrets
from datetime import date
from pathlib import Path
from typing import Any, Dict, List

from flask import (
    Flask,
    abort,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    send_file,
    url_for,
)

from backend.analytics import DEFAULT_CHARTS_DIR, compute_analytics_summary, generate_all_charts
from backend.expiry_engine import (
    get_expired_items,
    get_expires_today_items,
    get_expiring_soon_only,
    identify_critical_situations,
)
from backend.import_export import ImportSummary, import_csv_text
from backend.inventory import InventoryService
from backend.models import (
    ALL_EXPIRY_STATUSES,
    FOOD_CATEGORIES,
    MEASUREMENT_UNITS,
    STORAGE_LOCATIONS,
)
from backend.report_generator import (
    DEFAULT_REPORTS_DIR,
    generate_csv_report,
    generate_markdown_report,
    generate_text_report,
    list_generated_reports,
)
from backend.search import filter_and_search, paginate_items


BASE_DIR = Path(__file__).resolve().parent


def create_app(data_dir: Path | None = None) -> Flask:
    """Application factory for Flask web interface."""
    app = Flask(
        __name__,
        template_folder=str(BASE_DIR / "templates"),
        static_folder=str(BASE_DIR / "static"),
    )
    app.secret_key = os.environ.get("FLASK_SECRET_KEY") or secrets.token_hex(32)
    app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB CSV upload limit

    service = InventoryService(data_dir=data_dir)
    reports_dir = (Path(data_dir).parent / "reports") if data_dir else DEFAULT_REPORTS_DIR
    charts_dir = reports_dir / "charts"

    @app.context_processor
    def inject_globals() -> Dict[str, Any]:
        return {
            "today_iso": date.today().isoformat(),
            "categories": FOOD_CATEGORIES,
            "units": MEASUREMENT_UNITS,
            "locations": STORAGE_LOCATIONS,
            "statuses": ALL_EXPIRY_STATUSES,
        }

    @app.route("/api/health")
    def health_check():
        return jsonify({"status": "ok", "service": "food-expiry-tracker", "engine": "python-flask"})

    @app.route("/")
    def dashboard():
        summary = service.get_dashboard_summary()
        return render_template(
            "dashboard.html",
            active_page="dashboard",
            page_title="Dashboard",
            summary=summary,
        )

    @app.route("/inventory")
    def inventory():
        items, warnings = service.load_all()
        query = request.args.get("q", "").strip()
        category = request.args.get("category", "all").strip()
        status = request.args.get("status", "all").strip()
        location = request.args.get("location", "all").strip()
        sort_by = request.args.get("sort_by", "expiry_date").strip()
        sort_order = request.args.get("sort_order", "asc").strip()

        try:
            page = int(request.args.get("page", "1"))
        except ValueError:
            page = 1
        try:
            per_page = int(request.args.get("per_page", "10"))
        except ValueError:
            per_page = 10

        filtered = filter_and_search(
            items,
            query=query,
            category=category,
            status=status,
            location=location,
            sort_by=sort_by,
            sort_order=sort_order,
        )
        paged = paginate_items(filtered, page=page, per_page=per_page)

        return render_template(
            "inventory.html",
            active_page="inventory",
            page_title="Inventory Management",
            paged=paged,
            total_all=len(items),
            warnings=warnings,
            filters={
                "q": query,
                "category": category,
                "status": status,
                "location": location,
                "sort_by": sort_by,
                "sort_order": sort_order,
                "per_page": per_page,
            },
        )

    @app.route("/add", methods=["GET", "POST"])
    def add_item():
        form_data: Dict[str, Any] = {
            "name": "",
            "category": "Dairy",
            "quantity": "",
            "unit": "pcs",
            "purchase_date": date.today().isoformat(),
            "expiry_date": "",
            "storage_location": "Refrigerator",
            "notes": "",
        }
        errors: Dict[str, str] = {}

        if request.method == "POST":
            form_data = {
                "name": request.form.get("name", ""),
                "category": request.form.get("category", ""),
                "quantity": request.form.get("quantity", ""),
                "unit": request.form.get("unit", ""),
                "purchase_date": request.form.get("purchase_date", ""),
                "expiry_date": request.form.get("expiry_date", ""),
                "storage_location": request.form.get("storage_location", ""),
                "notes": request.form.get("notes", ""),
            }
            created, errors = service.add_item(form_data)
            if not errors and created is not None:
                flash(
                    f"Added '{created.item.name}' ({created.item.item_id}) — Status: {created.status}.",
                    "success",
                )
                return redirect(url_for("inventory"))

        return render_template(
            "add_item.html",
            active_page="add",
            page_title="Add Pantry Item",
            form_data=form_data,
            errors=errors,
        )

    @app.route("/edit/<item_id>", methods=["GET", "POST"])
    def edit_item(item_id: str):
        existing = service.get_item(item_id)
        if existing is None:
            flash(f"Pantry item '{item_id}' was not found.", "error")
            return redirect(url_for("inventory"))

        form_data: Dict[str, Any] = existing.item.to_dict()
        errors: Dict[str, str] = {}

        if request.method == "POST":
            form_data = {
                "item_id": existing.item.item_id,
                "name": request.form.get("name", ""),
                "category": request.form.get("category", ""),
                "quantity": request.form.get("quantity", ""),
                "unit": request.form.get("unit", ""),
                "purchase_date": request.form.get("purchase_date", ""),
                "expiry_date": request.form.get("expiry_date", ""),
                "storage_location": request.form.get("storage_location", ""),
                "notes": request.form.get("notes", ""),
            }
            updated, errors = service.update_item(item_id, form_data)
            if not errors and updated is not None:
                flash(
                    f"Updated '{updated.item.name}' ({updated.item.item_id}) — Status: {updated.status}.",
                    "success",
                )
                return redirect(url_for("inventory"))

        return render_template(
            "edit_item.html",
            active_page="inventory",
            page_title=f"Edit {existing.item.name}",
            item=existing,
            form_data=form_data,
            errors=errors,
        )

    @app.route("/delete/<item_id>", methods=["POST"])
    def delete_item(item_id: str):
        ok, deleted = service.delete_item(item_id)
        if ok and deleted:
            flash(f"Deleted '{deleted.name}' ({deleted.item_id}) from inventory.", "success")
        else:
            flash(f"Item '{item_id}' could not be found.", "error")
        return redirect(request.referrer or url_for("inventory"))

    @app.route("/alerts")
    def expiry_alerts():
        items, warnings = service.load_all()
        category = request.args.get("category", "all").strip()
        expiry_before = request.args.get("expiry_before", "").strip()
        expiry_after = request.args.get("expiry_after", "").strip()

        filtered = filter_and_search(
            items,
            category=category,
            expiry_before=expiry_before,
            expiry_after=expiry_after,
            sort_by="days_remaining",
            sort_order="asc",
        )

        expired_items = get_expired_items(filtered)
        expires_today_items = get_expires_today_items(filtered)
        expiring_soon_items = get_expiring_soon_only(filtered, within_days=7)
        anomalous_items = [e for e in filtered if e.anomaly_warning]
        critical_warnings = identify_critical_situations(filtered)

        return render_template(
            "expiry_alerts.html",
            active_page="alerts",
            page_title="Expiry Alerts",
            expired_items=expired_items,
            expires_today_items=expires_today_items,
            expiring_soon_items=expiring_soon_items,
            anomalous_items=anomalous_items,
            critical_warnings=critical_warnings,
            storage_warnings=warnings,
            filters={
                "category": category,
                "expiry_before": expiry_before,
                "expiry_after": expiry_after,
            },
        )

    @app.route("/analytics")
    def analytics():
        items, warnings = service.load_all()
        summary = compute_analytics_summary(items)
        chart_files = generate_all_charts(items, charts_dir=charts_dir)
        cache_bust = int(date.today().strftime("%Y%m%d")) + len(items)
        return render_template(
            "analytics.html",
            active_page="analytics",
            page_title="Analytics & Charts",
            summary=summary,
            chart_files=chart_files,
            cache_bust=cache_bust,
            warnings=warnings,
        )

    @app.route("/charts/<path:filename>")
    def serve_chart(filename: str):
        safe_base = charts_dir.resolve()
        target = (safe_base / filename).resolve()
        if not target.is_relative_to(safe_base) or not target.is_file():
            abort(404)
        response = send_file(target, mimetype="image/png")
        response.headers["Cache-Control"] = "no-store, max-age=0"
        return response

    @app.route("/reports", methods=["GET", "POST"])
    def reports():
        items, _ = service.load_all()
        summary = compute_analytics_summary(items)
        latest_generated = None

        if request.method == "POST":
            fmt = request.form.get("format", "").strip().lower()
            if fmt == "markdown":
                path = generate_markdown_report(items, output_dir=reports_dir)
                latest_generated = ("markdown", path.name)
                flash(f"Generated Markdown report: {path.name}", "success")
            elif fmt == "text":
                path = generate_text_report(items, output_dir=reports_dir)
                latest_generated = ("text", path.name)
                flash(f"Generated Plain Text report: {path.name}", "success")
            elif fmt == "csv":
                path = generate_csv_report(items, output_dir=reports_dir)
                latest_generated = ("csv", path.name)
                flash(f"Generated CSV report: {path.name}", "success")
            else:
                flash("Unsupported report format requested.", "error")

        existing_reports = list_generated_reports(output_dir=reports_dir)
        return render_template(
            "reports.html",
            active_page="reports",
            page_title="Export Reports",
            summary=summary,
            existing_reports=existing_reports,
            latest_generated=latest_generated,
        )

    @app.route("/reports/download/<folder>/<filename>")
    def download_report(folder: str, filename: str):
        if folder not in ("markdown", "text", "csv"):
            abort(404)
        safe_base = (reports_dir / folder).resolve()
        target = (safe_base / filename).resolve()
        if not target.is_relative_to(safe_base) or not target.is_file():
            abort(404)
        return send_file(target, as_attachment=True, download_name=target.name)

    @app.route("/import", methods=["GET", "POST"])
    def import_data():
        import_summary: ImportSummary | None = None

        if request.method == "POST":
            action = request.form.get("action", "upload")
            if action == "load_demo":
                added, skipped = service.restore_demo_dataset(overwrite=False)
                flash(
                    f"Loaded {added} sample pantry record(s) ({skipped} duplicate record(s) preserved).",
                    "success",
                )
                return redirect(url_for("import_data"))

            uploaded = request.files.get("csv_file")
            if uploaded is None or not uploaded.filename:
                flash("Please select a .csv file to upload.", "error")
            elif not uploaded.filename.lower().endswith(".csv"):
                flash("Invalid file extension. Only .csv files are permitted.", "error")
            else:
                raw_bytes = uploaded.read()
                try:
                    csv_text = raw_bytes.decode("utf-8")
                except UnicodeDecodeError:
                    try:
                        csv_text = raw_bytes.decode("latin-1")
                    except UnicodeDecodeError:
                        flash("Unable to decode CSV file. Please save it as UTF-8.", "error")
                        csv_text = ""

                if csv_text:
                    import_summary = import_csv_text(csv_text, service)
                    if import_summary.success and import_summary.imported_count > 0:
                        flash(
                            f"Imported {import_summary.imported_count} valid record(s). "
                            f"{import_summary.failed_count} row(s) skipped.",
                            "success",
                        )
                    elif import_summary.header_errors:
                        flash("CSV import failed due to header or format errors.", "error")
                    else:
                        flash("CSV processed: no new valid records were imported.", "error")

        return render_template(
            "import_data.html",
            active_page="import",
            page_title="Import CSV Dataset",
            import_summary=import_summary,
        )

    @app.route("/import/sample-template")
    def download_sample_csv():
        sample_path = service.storage.sample_csv_path.resolve()
        if not sample_path.is_file():
            abort(404)
        return send_file(sample_path, as_attachment=True, download_name="sample_dataset.csv")

    return app


app = create_app()


if __name__ == "__main__":
    port = int(os.environ.get("FLASK_PORT", os.environ.get("PORT", "5000")))
    host = os.environ.get("FLASK_HOST", "127.0.0.1")
    app.run(host=host, port=port, debug=False)
