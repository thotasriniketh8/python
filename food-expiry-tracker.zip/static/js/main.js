/* Lightweight client-side interaction enhancements (business logic remains strictly in Python). */

document.addEventListener("DOMContentLoaded", () => {
  // Mobile sidebar drawer
  const sidebar = document.getElementById("app-sidebar");
  const backdrop = document.getElementById("sidebar-backdrop");
  const openBtn = document.getElementById("mobile-menu-btn");
  const closeBtn = document.getElementById("mobile-close-btn");

  const setDrawer = (open) => {
    if (!sidebar || !backdrop) return;
    sidebar.classList.toggle("open", open);
    backdrop.classList.toggle("open", open);
    if (openBtn) openBtn.setAttribute("aria-expanded", open ? "true" : "false");
  };

  if (openBtn) openBtn.addEventListener("click", () => setDrawer(true));
  if (closeBtn) closeBtn.addEventListener("click", () => setDrawer(false));
  if (backdrop) backdrop.addEventListener("click", () => setDrawer(false));

  // Dismiss flash messages
  document.querySelectorAll("[data-dismiss-flash]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const banner = btn.closest(".flash-banner");
      if (banner) banner.remove();
    });
  });

  // Accessible delete confirmation dialog (avoids window.confirm)
  const deleteDialog = document.getElementById("delete-confirm-dialog");
  const deleteDialogName = document.getElementById("delete-dialog-item-name");
  const deleteCancelBtn = document.getElementById("delete-dialog-cancel");
  const deleteConfirmBtn = document.getElementById("delete-dialog-confirm");
  let pendingDeleteForm = null;

  document.querySelectorAll("form[data-confirm-delete]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      if (form.dataset.confirmed === "true") {
        return;
      }
      if (deleteDialog && typeof deleteDialog.showModal === "function") {
        event.preventDefault();
        pendingDeleteForm = form;
        if (deleteDialogName) {
          deleteDialogName.textContent = form.dataset.itemName || "this item";
        }
        deleteDialog.showModal();
      }
    });
  });

  if (deleteCancelBtn && deleteDialog) {
    deleteCancelBtn.addEventListener("click", () => {
      pendingDeleteForm = null;
      deleteDialog.close();
    });
  }

  if (deleteConfirmBtn && deleteDialog) {
    deleteConfirmBtn.addEventListener("click", () => {
      if (pendingDeleteForm) {
        pendingDeleteForm.dataset.confirmed = "true";
        pendingDeleteForm.submit();
      }
      deleteDialog.close();
    });
  }

  // Client-side pre-validation hint on Add/Edit item forms (Python remains authoritative)
  const itemForm = document.getElementById("pantry-item-form");
  if (itemForm) {
    const purchaseInput = itemForm.querySelector('input[name="purchase_date"]');
    const expiryInput = itemForm.querySelector('input[name="expiry_date"]');
    const dateHint = document.getElementById("client-date-hint");

    const checkDates = () => {
      if (!purchaseInput || !expiryInput || !dateHint) return;
      if (purchaseInput.value && expiryInput.value && expiryInput.value < purchaseInput.value) {
        dateHint.textContent = "Expiry date cannot be earlier than purchase date.";
        dateHint.style.color = "#b91c1c";
      } else {
        dateHint.textContent = "";
      }
    };

    if (purchaseInput) purchaseInput.addEventListener("change", checkDates);
    if (expiryInput) expiryInput.addEventListener("change", checkDates);
  }
});
