"""Interactive menu-driven Python terminal CLI for Food Expiry Tracker (StudentLife Hack Project #62)."""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path
from typing import Callable, List, Optional, Tuple

from backend.analytics import compute_analytics_summary
from backend.expiry_engine import (
    get_expired_items,
    get_expires_today_items,
    get_expiring_soon_only,
    identify_critical_situations,
)
from backend.import_export import import_csv_file
from backend.inventory import InventoryService
from backend.models import (
    ALL_EXPIRY_STATUSES,
    FOOD_CATEGORIES,
    MEASUREMENT_UNITS,
    STORAGE_LOCATIONS,
    EnrichedPantryItem,
)
from backend.report_generator import (
    generate_csv_report,
    generate_markdown_report,
    generate_text_report,
)
from backend.search import filter_and_search, paginate_items
from backend.validation import (
    parse_iso_date,
    validate_category,
    validate_name,
    validate_notes,
    validate_quantity,
    validate_storage_location,
    validate_unit,
)


BANNER = r"""
==============================================================================
   _____ ___   ___  ____    _______  ______ ___ ____  __   __
  |  ___/ _ \ / _ \|  _ \  | ____\ \/ /  _ \_ _|  _ \ \ \ / /
  | |_ | | | | | | | | | | |  _|  \  /| |_) | || |_) | \ V /
  |  _|| |_| | |_| | |_| | | |___ /  \|  __/| ||  _ <   | |
  |_|   \___/ \___/|____/  |_____/_/\_\_|  |___|_| \_\  |_|

   FOOD EXPIRY TRACKER  |  StudentLife Hack Project #62  |  Python CLI
==============================================================================
"""


def print_header(title: str) -> None:
    print("\n" + "=" * 78)
    print(f"  {title}")
    print("=" * 78)


def prompt_input(prompt_text: str, default: Optional[str] = None) -> str:
    """Safely read terminal input without crashing on EOF/KeyboardInterrupt."""
    suffix = f" [{default}]" if default is not None else ""
    try:
        raw = input(f"{prompt_text}{suffix}: ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\n[INFO] Input interrupted.")
        return ""
    if not raw and default is not None:
        return default
    return raw


def prompt_validated(
    label: str,
    validator: Callable[[str], Tuple[object, Optional[str]]],
    hint: str = "",
    default: Optional[str] = None,
) -> Optional[object]:
    """
    Centralized defensive input loop: repeatedly prompts until valid or 'cancel'.
    """
    while True:
        if hint:
            print(f"  Hint: {hint}")
        raw = prompt_input(f"  {label} (or type 'cancel' to abort)", default=default)
        if raw.lower() == "cancel":
            return None
        value, err = validator(raw)
        if err:
            print(f"  [Validation Error] {err}")
            continue
        return value


def display_paginated_table(items: List[EnrichedPantryItem], title: str, page_size: int = 10) -> None:
    """Render fixed-width terminal tables with column separators and pagination."""
    if not items:
        print_header(title)
        print("  No pantry records match this view.")
        return

    page = 1
    while True:
        paged = paginate_items(items, page=page, per_page=page_size)
        print_header(
            f"{title}  (Showing {paged['start_index']}-{paged['end_index']} of {paged['total']} | "
            f"Page {paged['page']}/{paged['total_pages']})"
        )
        header = (
            f"{'ID':<8} | {'Item Name':<22} | {'Category':<12} | {'Qty':<10} | "
            f"{'Expiry':<10} | {'Rem':>5} | {'Status':<13} | {'Location':<14}"
        )
        print(header)
        print("-" * len(header))

        for e in paged["items"]:
            i = e.item
            name_col = (i.name[:19] + "...") if len(i.name) > 22 else i.name
            cat_col = (i.category[:12])
            qty_col = f"{i.quantity:g} {i.unit}"[:10]
            rem_col = "Today" if e.days_remaining == 0 else f"{e.days_remaining}d"
            loc_col = (i.storage_location[:14])
            flag = "!" if e.is_critical else " "
            print(
                f"{i.item_id:<8} | {name_col:<22} | {cat_col:<12} | {qty_col:<10} | "
                f"{i.expiry_date:<10} | {rem_col:>5} | {flag}{e.status:<12} | {loc_col:<14}"
            )

        print("-" * len(header))
        if paged["total_pages"] <= 1:
            break

        nav_opts = []
        if paged["has_next"]:
            nav_opts.append("[N] Next")
        if paged["has_prev"]:
            nav_opts.append("[P] Prev")
        nav_opts.append("[B] Back to Menu")
        choice = prompt_input("  Navigation (" + " / ".join(nav_opts) + ")").lower()
        if choice == "n" and paged["has_next"]:
            page += 1
        elif choice == "p" and paged["has_prev"]:
            page -= 1
        else:
            break


def handle_add_item(service: InventoryService) -> None:
    """Menu 1: Add a Pantry Item with repeated defensive prompts."""
    print_header("ADD A NEW PANTRY ITEM")
    print("  Type 'cancel' at any prompt to return to the main menu.\n")

    name = prompt_validated("Food item name", validate_name, hint="e.g., Organic Whole Milk")
    if name is None:
        print("  [Cancelled] Item creation aborted.")
        return

    print(f"  Categories: {', '.join(FOOD_CATEGORIES)}")
    category = prompt_validated("Category", validate_category)
    if category is None:
        print("  [Cancelled] Item creation aborted.")
        return

    quantity = prompt_validated("Quantity", validate_quantity, hint="Positive number, e.g., 2 or 1.5")
    if quantity is None:
        print("  [Cancelled] Item creation aborted.")
        return

    print(f"  Common units: {', '.join(MEASUREMENT_UNITS)}")
    unit = prompt_validated("Unit of measurement", validate_unit, default="pcs")
    if unit is None:
        print("  [Cancelled] Item creation aborted.")
        return

    today_str = date.today().isoformat()
    while True:
        purchase_raw = prompt_input("  Purchase date (YYYY-MM-DD, or 'cancel')", default=today_str)
        if purchase_raw.lower() == "cancel":
            print("  [Cancelled] Item creation aborted.")
            return
        p_date, p_err = parse_iso_date(purchase_raw)
        if p_err or p_date is None:
            print(f"  [Validation Error] {p_err}")
            continue
        break

    while True:
        expiry_raw = prompt_input("  Expiry date (YYYY-MM-DD, or 'cancel')")
        if expiry_raw.lower() == "cancel":
            print("  [Cancelled] Item creation aborted.")
            return
        e_date, e_err = parse_iso_date(expiry_raw)
        if e_err or e_date is None:
            print(f"  [Validation Error] {e_err}")
            continue
        if e_date < p_date:
            print(
                f"  [Validation Error] Expiry date ({e_date.isoformat()}) cannot be earlier "
                f"than purchase date ({p_date.isoformat()})."
            )
            continue
        break

    print(f"  Locations: {', '.join(STORAGE_LOCATIONS)}")
    location = prompt_validated("Storage location", validate_storage_location, default="Refrigerator")
    if location is None:
        print("  [Cancelled] Item creation aborted.")
        return

    notes = prompt_validated("Additional notes (optional)", validate_notes, default="")
    if notes is None:
        print("  [Cancelled] Item creation aborted.")
        return

    payload = {
        "name": name,
        "category": category,
        "quantity": quantity,
        "unit": unit,
        "purchase_date": p_date.isoformat(),
        "expiry_date": e_date.isoformat(),
        "storage_location": location,
        "notes": notes,
    }
    created, errors = service.add_item(payload)
    if errors or created is None:
        print("\n  [Error] Could not save item:")
        for field, msg in errors.items():
            print(f"    - {field}: {msg}")
        return

    print(
        f"\n  [Success] Saved '{created.item.name}' (ID: {created.item.item_id}) | "
        f"Status: {created.status} ({created.days_remaining} day(s) remaining)."
    )


def handle_view_all(service: InventoryService) -> None:
    """Menu 2: View All Pantry Items with optional quick edit/delete."""
    items, warnings = service.load_all()
    for w in warnings:
        print(f"  [Storage Warning] {w}")
    sorted_items = filter_and_search(items, sort_by="expiry_date", sort_order="asc")
    display_paginated_table(sorted_items, "ALL PANTRY ITEMS (Sorted by Expiry Date)")

    if not sorted_items:
        return

    action = prompt_input("\n  Optional action: [E]dit by ID, [D]elete by ID, or Enter to return").lower()
    if action == "e":
        item_id = prompt_input("  Enter Item ID to edit (e.g., FD-1001)").upper()
        existing = service.get_item(item_id)
        if not existing:
            print(f"  [Error] Item '{item_id}' not found.")
            return
        print(f"  Editing '{existing.item.name}' (press Enter to keep current value):")
        name = prompt_validated("Name", validate_name, default=existing.item.name)
        category = prompt_validated("Category", validate_category, default=existing.item.category)
        qty = prompt_validated("Quantity", validate_quantity, default=str(existing.item.quantity))
        unit = prompt_validated("Unit", validate_unit, default=existing.item.unit)
        location = prompt_validated("Location", validate_storage_location, default=existing.item.storage_location)
        if None in (name, category, qty, unit, location):
            print("  [Cancelled] Update aborted.")
            return
        updated, errs = service.update_item(
            item_id,
            {
                "name": name,
                "category": category,
                "quantity": qty,
                "unit": unit,
                "purchase_date": existing.item.purchase_date,
                "expiry_date": existing.item.expiry_date,
                "storage_location": location,
                "notes": existing.item.notes,
            },
        )
        if errs or not updated:
            print("  [Error] Update failed:", errs)
        else:
            print(f"  [Success] Updated '{updated.item.name}' ({updated.item.item_id}).")
    elif action == "d":
        item_id = prompt_input("  Enter Item ID to delete (e.g., FD-1001)").upper()
        confirm = prompt_input(f"  Confirm delete '{item_id}'? (y/N)").lower()
        if confirm == "y":
            ok, deleted = service.delete_item(item_id)
            if ok and deleted:
                print(f"  [Success] Deleted '{deleted.name}' ({deleted.item_id}).")
            else:
                print(f"  [Error] Item '{item_id}' not found.")


def handle_search(service: InventoryService) -> None:
    """Menu 3: Search Items by keyword, category, location, and expiry status."""
    print_header("SEARCH & FILTER PANTRY ITEMS")
    items, _ = service.load_all()
    query = prompt_input("  Keyword (name, location, notes, or ID; Enter for all)", default="")
    print(f"  Categories: All, {', '.join(FOOD_CATEGORIES)}")
    category = prompt_input("  Category filter", default="All")
    print(f"  Statuses: All, {', '.join(ALL_EXPIRY_STATUSES)}")
    status = prompt_input("  Expiry status filter", default="All")
    location = prompt_input("  Storage location filter (Enter for All)", default="All")

    results = filter_and_search(
        items,
        query=query,
        category=category,
        status=status,
        location=location,
        sort_by="expiry_date",
        sort_order="asc",
    )
    if not results:
        print("\n  [No Matches] No pantry records matched your search criteria.")
        return
    display_paginated_table(results, f"SEARCH RESULTS ({len(results)} match(es))")


def handle_view_expiring(service: InventoryService) -> None:
    """Menu 4: View Expiring Items (Expires Today + Expiring Soon <= 7 days)."""
    items, _ = service.load_all()
    today_items = get_expires_today_items(items)
    soon_items = get_expiring_soon_only(items, within_days=7)
    combined = today_items + soon_items
    display_paginated_table(combined, "EXPIRING ITEMS (Expires Today & Next 7 Days)")


def handle_view_expired(service: InventoryService) -> None:
    """Menu 5: View Already Expired Items."""
    items, _ = service.load_all()
    expired = get_expired_items(items)
    display_paginated_table(expired, "EXPIRED PANTRY ITEMS")


def handle_inventory_summary(service: InventoryService) -> None:
    """Menu 6: View Executive Inventory Summary (Pandas & NumPy backed)."""
    items, warnings = service.load_all()
    summary = compute_analytics_summary(items)
    critical = identify_critical_situations(items)

    print_header("EXECUTIVE INVENTORY SUMMARY (Python Analytics)")
    for w in warnings:
        print(f"  [Storage Warning] {w}")

    print(f"  Generated At                  : {summary['generated_at']}")
    print(f"  Total Pantry Records          : {summary['total_records']}")
    print(f"  Total Inventory Quantity      : {summary['total_quantity']}")
    print(f"  Fresh Items (> 7 days)        : {summary['fresh_count']}")
    print(f"  Expiring Soon (1 - 7 days)    : {summary['expiring_soon_count']}")
    print(f"  Expires Today (0 days)        : {summary['expires_today_count']}")
    print(f"  Expired Items (< 0 days)      : {summary['expired_count']}")
    print(f"  Avg Shelf Life (All Items)    : {summary['avg_remaining_shelf_life_all']} days")
    print(f"  Avg Shelf Life (Active Stock) : {summary['avg_remaining_shelf_life_active']} days")
    print(f"  Median Days Remaining         : {summary['median_days_remaining']} days")

    if critical:
        print("\n  ACTIVE WARNINGS:")
        print("  " + "-" * 74)
        for c in critical:
            print(f"  [{c['severity'].upper()}] {c['title']} - {c['detail']}")

    if summary["category_summary"]:
        print("\n  CATEGORY BREAKDOWN:")
        print(f"  {'Category':<16} | {'Items':>5} | {'Share':>6} | {'Total Qty':>10} | {'Avg Days':>8}")
        print("  " + "-" * 58)
        for cat in summary["category_summary"]:
            print(
                f"  {cat['category']:<16} | {cat['count']:>5} | {cat['percentage']:>5}% | "
                f"{cat['total_quantity']:>10} | {cat['avg_days_remaining']:>8}"
            )


def handle_export_reports(service: InventoryService) -> None:
    """Menu 7: Export Markdown, Plain Text, and CSV reports."""
    print_header("EXPORT INVENTORY REPORTS")
    print("  1. Export Markdown Report (.md)")
    print("  2. Export Plain Text Report (.txt)")
    print("  3. Export CSV Report (.csv)")
    print("  4. Export All Three Formats")
    print("  5. Cancel")

    choice = prompt_input("  Select export option (1-5)")
    items, _ = service.load_all()
    generated: List[Path] = []

    if choice == "1":
        generated.append(generate_markdown_report(items))
    elif choice == "2":
        generated.append(generate_text_report(items))
    elif choice == "3":
        generated.append(generate_csv_report(items))
    elif choice == "4":
        generated.append(generate_markdown_report(items))
        generated.append(generate_text_report(items))
        generated.append(generate_csv_report(items))
    else:
        print("  Export cancelled.")
        return

    print("\n  [Success] Report(s) generated:")
    for path in generated:
        print(f"    -> {path}")


def handle_import_csv(service: InventoryService) -> None:
    """Menu 8: Import CSV Dataset with row-by-row defensive validation."""
    print_header("IMPORT CSV DATASET")
    sample_path = service.storage.sample_csv_path
    print(f"  Sample dataset available at: {sample_path}")
    raw_path = prompt_input("  Enter path to CSV file (or press Enter for sample dataset)", default=str(sample_path))
    if not raw_path:
        print("  Import cancelled.")
        return

    result = import_csv_file(Path(raw_path), service)
    if result.header_errors:
        print("\n  [Import Failed] Header/File Errors:")
        for err in result.header_errors:
            print(f"    - {err}")
        return

    print("\n  IMPORT SUMMARY:")
    print(f"    Total Rows Processed : {result.total_rows}")
    print(f"    Successfully Imported: {result.imported_count}")
    print(f"    Failed / Skipped     : {result.failed_count} (Duplicates: {result.duplicate_count})")
    if result.row_errors:
        print("\n  ROW ERROR LOG (showing up to 10):")
        for entry in result.row_errors[:10]:
            print(f"    Row {entry['row']} ({entry['name']}): {'; '.join(entry['errors'])}")


def run_cli(data_dir: Optional[Path] = None) -> None:
    """Main interactive terminal menu loop."""
    service = InventoryService(data_dir=data_dir)
    print(BANNER)

    while True:
        print("\n  MAIN MENU")
        print("  " + "-" * 40)
        print("  1. Add a Pantry Item")
        print("  2. View All Pantry Items")
        print("  3. Search Items")
        print("  4. View Expiring Items")
        print("  5. View Expired Items")
        print("  6. View Inventory Summary")
        print("  7. Export Reports")
        print("  8. Import CSV Dataset")
        print("  9. Exit")
        print("  " + "-" * 40)

        choice = prompt_input("  Enter your choice (1-9)")
        if choice == "1":
            handle_add_item(service)
        elif choice == "2":
            handle_view_all(service)
        elif choice == "3":
            handle_search(service)
        elif choice == "4":
            handle_view_expiring(service)
        elif choice == "5":
            handle_view_expired(service)
        elif choice == "6":
            handle_inventory_summary(service)
        elif choice == "7":
            handle_export_reports(service)
        elif choice == "8":
            handle_import_csv(service)
        elif choice == "9":
            print("\n  Thank you for using Food Expiry Tracker. Stay fresh and reduce waste!\n")
            break
        else:
            print("  [Invalid Choice] Please enter a number from 1 to 9.")


if __name__ == "__main__":
    run_cli()
