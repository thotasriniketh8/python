import { spawn, type ChildProcess } from 'node:child_process';
import http from 'node:http';

const PUBLIC_PORT = Number(process.env.PORT || 3000);
const FLASK_HOST = '127.0.0.1';
const FLASK_PORT = Number(process.env.FLASK_PORT || 5051);

let flaskProcess: ChildProcess | null = null;
let flaskReady = false;

function startFlask(): void {
  flaskProcess = spawn('python3', ['app.py'], {
    env: {
      ...process.env,
      FLASK_HOST,
      FLASK_PORT: String(FLASK_PORT),
      PYTHONUNBUFFERED: '1',
    },
    stdio: 'inherit',
  });

  flaskProcess.on('exit', (code) => {
    flaskReady = false;
    console.error(`[bridge] Python Flask exited with code ${code ?? 'null'}`);
  });
}

async function waitForFlask(timeoutMs = 15000): Promise<boolean> {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const ok = await new Promise<boolean>((resolve) => {
      const req = http.get(
        { host: FLASK_HOST, port: FLASK_PORT, path: '/api/health', timeout: 800 },
        (res) => {
          res.resume();
          resolve(res.statusCode === 200);
        }
      );
      req.on('error', () => resolve(false));
      req.on('timeout', () => {
        req.destroy();
        resolve(false);
      });
    });
    if (ok) {
      flaskReady = true;
      return true;
    }
    await new Promise((r) => setTimeout(r, 150));
  }
  return false;
}

const server = http.createServer(async (req, res) => {
  if (!flaskReady) {
    await waitForFlask(10000);
  }

  const headers = { ...req.headers };
  if (req.headers.host) {
    headers['x-forwarded-host'] = req.headers.host;
  }

  const proxyReq = http.request(
    {
      host: FLASK_HOST,
      port: FLASK_PORT,
      path: req.url || '/',
      method: req.method || 'GET',
      headers,
    },
    (proxyRes) => {
      res.writeHead(proxyRes.statusCode || 502, proxyRes.headers);
      proxyRes.pipe(res, { end: true });
    }
  );

  proxyReq.on('error', (err) => {
    if (!res.headersSent) {
      res.writeHead(502, { 'Content-Type': 'text/plain; charset=utf-8' });
    }
    res.end(`Python Flask backend unavailable: ${err.message}`);
  });

  req.pipe(proxyReq, { end: true });
});

function shutdown(): void {
  if (flaskProcess && !flaskProcess.killed) {
    flaskProcess.kill('SIGTERM');
  }
  server.close(() => process.exit(0));
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

startFlask();
waitForFlask(15000).then((ready) => {
  if (!ready) {
    console.warn('[bridge] Flask health check did not respond within startup window.');
  }
  server.listen(PUBLIC_PORT, '0.0.0.0', () => {
    console.log(`[bridge] Proxying http://0.0.0.0:${PUBLIC_PORT} -> Python Flask http://${FLASK_HOST}:${FLASK_PORT}`);
  });
});
